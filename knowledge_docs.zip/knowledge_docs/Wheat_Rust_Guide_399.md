# Wheat Rust Guide

- **Crop:** Wheat  
- **Disease:** Rust  
- **Region:** Assam  
- **Language:** Tamil  
- **Date:** 2020-02-13  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.9 °C  
- Humidity: 63%  
- Rainfall: 45 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.5  
- Organic Carbon: 1.95%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
