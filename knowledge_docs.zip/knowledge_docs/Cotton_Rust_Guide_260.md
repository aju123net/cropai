# Cotton Rust Guide

- **Crop:** Cotton  
- **Disease:** Rust  
- **Region:** Gujarat  
- **Language:** Hindi  
- **Date:** 2021-03-02  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.9 °C  
- Humidity: 83%  
- Rainfall: 4 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.54%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
