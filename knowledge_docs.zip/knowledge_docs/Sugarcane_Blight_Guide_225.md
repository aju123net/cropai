# Sugarcane Blight Guide

- **Crop:** Sugarcane  
- **Disease:** Blight  
- **Region:** Tamil Nadu  
- **Language:** Bengali  
- **Date:** 2023-02-20  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.0 °C  
- Humidity: 89%  
- Rainfall: 14 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.3%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
