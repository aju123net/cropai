# Maize Wilt Guide

- **Crop:** Maize  
- **Disease:** Wilt  
- **Region:** Assam  
- **Language:** Hindi  
- **Date:** 2023-09-07  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.2 °C  
- Humidity: 64%  
- Rainfall: 28 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.1  
- Organic Carbon: 1.19%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
