# Maize Blight Guide

- **Crop:** Maize  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2021-02-06  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.6 °C  
- Humidity: 67%  
- Rainfall: 22 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.1  
- Organic Carbon: 1.74%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
