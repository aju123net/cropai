# Wheat Brown Spot Guide

- **Crop:** Wheat  
- **Disease:** Brown Spot  
- **Region:** Karnataka  
- **Language:** Tamil  
- **Date:** 2025-07-21  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.2 °C  
- Humidity: 85%  
- Rainfall: 17 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.67%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
