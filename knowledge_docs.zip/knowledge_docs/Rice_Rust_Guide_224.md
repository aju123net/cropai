# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** Bihar  
- **Language:** Bengali  
- **Date:** 2019-11-21  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.5 °C  
- Humidity: 88%  
- Rainfall: 14 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.5  
- Organic Carbon: 1.66%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
