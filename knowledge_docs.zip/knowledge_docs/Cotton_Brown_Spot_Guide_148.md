# Cotton Brown Spot Guide

- **Crop:** Cotton  
- **Disease:** Brown Spot  
- **Region:** Karnataka  
- **Language:** English  
- **Date:** 2017-12-10  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.1 °C  
- Humidity: 49%  
- Rainfall: 23 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.0  
- Organic Carbon: 0.84%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
