# Tomato Virus Guide

- **Crop:** Tomato  
- **Disease:** Virus  
- **Region:** Uttar Pradesh  
- **Language:** Bengali  
- **Date:** 2017-05-03  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.3 °C  
- Humidity: 69%  
- Rainfall: 39 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.15%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
