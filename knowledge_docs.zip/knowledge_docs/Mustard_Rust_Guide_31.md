# Mustard Rust Guide

- **Crop:** Mustard  
- **Disease:** Rust  
- **Region:** Bihar  
- **Language:** Hindi  
- **Date:** 2019-09-15  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.0 °C  
- Humidity: 78%  
- Rainfall: 40 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.67%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
