# Rice Blast Guide

- **Crop:** Rice  
- **Disease:** Blast  
- **Region:** Tamil Nadu  
- **Language:** Tamil  
- **Date:** 2020-06-28  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.6 °C  
- Humidity: 57%  
- Rainfall: 42 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.4  
- Organic Carbon: 0.89%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
