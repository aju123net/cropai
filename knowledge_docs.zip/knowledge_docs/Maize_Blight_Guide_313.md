# Maize Blight Guide

- **Crop:** Maize  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2018-03-04  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 35.0 °C  
- Humidity: 86%  
- Rainfall: 19 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.48%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
