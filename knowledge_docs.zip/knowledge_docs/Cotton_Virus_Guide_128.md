# Cotton Virus Guide

- **Crop:** Cotton  
- **Disease:** Virus  
- **Region:** West Bengal  
- **Language:** English  
- **Date:** 2016-11-21  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.6 °C  
- Humidity: 44%  
- Rainfall: 9 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.93%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
