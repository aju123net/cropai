# Cotton Blast Guide

- **Crop:** Cotton  
- **Disease:** Blast  
- **Region:** Uttar Pradesh  
- **Language:** Bengali  
- **Date:** 2016-07-24  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.2 °C  
- Humidity: 43%  
- Rainfall: 5 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.89%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
