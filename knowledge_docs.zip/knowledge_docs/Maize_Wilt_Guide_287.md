# Maize Wilt Guide

- **Crop:** Maize  
- **Disease:** Wilt  
- **Region:** Punjab  
- **Language:** English  
- **Date:** 2017-03-31  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.6 °C  
- Humidity: 46%  
- Rainfall: 14 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.12%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
