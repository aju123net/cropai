# Mustard Rust Guide

- **Crop:** Mustard  
- **Disease:** Rust  
- **Region:** Karnataka  
- **Language:** Tamil  
- **Date:** 2025-03-06  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.8 °C  
- Humidity: 75%  
- Rainfall: 20 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.1  
- Organic Carbon: 1.06%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
