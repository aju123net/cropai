# Potato Blast Guide

- **Crop:** Potato  
- **Disease:** Blast  
- **Region:** Uttar Pradesh  
- **Language:** English  
- **Date:** 2022-10-07  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.0 °C  
- Humidity: 48%  
- Rainfall: 27 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.4  
- Organic Carbon: 1.51%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
