# Potato Rust Guide

- **Crop:** Potato  
- **Disease:** Rust  
- **Region:** Bihar  
- **Language:** Hindi  
- **Date:** 2019-06-05  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.0 °C  
- Humidity: 69%  
- Rainfall: 42 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.5  
- Organic Carbon: 0.86%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
