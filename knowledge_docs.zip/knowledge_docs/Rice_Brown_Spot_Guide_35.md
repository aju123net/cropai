# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Odisha  
- **Language:** Bengali  
- **Date:** 2021-08-07  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.9 °C  
- Humidity: 80%  
- Rainfall: 43 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.5  
- Organic Carbon: 1.59%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
