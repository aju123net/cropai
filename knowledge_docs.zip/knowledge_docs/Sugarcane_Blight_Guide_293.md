# Sugarcane Blight Guide

- **Crop:** Sugarcane  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** English  
- **Date:** 2017-09-22  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.4 °C  
- Humidity: 59%  
- Rainfall: 33 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.5  
- Organic Carbon: 1.69%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
