# Rice Virus Guide

- **Crop:** Rice  
- **Disease:** Virus  
- **Region:** Punjab  
- **Language:** English  
- **Date:** 2021-10-22  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.2 °C  
- Humidity: 47%  
- Rainfall: 25 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.9  
- Organic Carbon: 0.59%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
