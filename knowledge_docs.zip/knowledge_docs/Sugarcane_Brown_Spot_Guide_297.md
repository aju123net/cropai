# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Maharashtra  
- **Language:** Hindi  
- **Date:** 2026-04-14  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.8 °C  
- Humidity: 46%  
- Rainfall: 16 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.6  
- Organic Carbon: 1.16%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
