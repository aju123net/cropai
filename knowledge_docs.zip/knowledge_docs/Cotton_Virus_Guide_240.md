# Cotton Virus Guide

- **Crop:** Cotton  
- **Disease:** Virus  
- **Region:** West Bengal  
- **Language:** Hindi  
- **Date:** 2026-05-16  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.1 °C  
- Humidity: 49%  
- Rainfall: 31 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.9  
- Organic Carbon: 1.81%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
