# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Assam  
- **Language:** Tamil  
- **Date:** 2021-07-06  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.4 °C  
- Humidity: 52%  
- Rainfall: 26 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.31%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
