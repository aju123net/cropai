# Cotton Wilt Guide

- **Crop:** Cotton  
- **Disease:** Wilt  
- **Region:** Maharashtra  
- **Language:** Bengali  
- **Date:** 2021-08-20  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.6 °C  
- Humidity: 76%  
- Rainfall: 22 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.8  
- Organic Carbon: 1.17%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
