# Cotton Rust Guide

- **Crop:** Cotton  
- **Disease:** Rust  
- **Region:** West Bengal  
- **Language:** Tamil  
- **Date:** 2024-04-14  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.6 °C  
- Humidity: 68%  
- Rainfall: 15 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.2  
- Organic Carbon: 0.68%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
