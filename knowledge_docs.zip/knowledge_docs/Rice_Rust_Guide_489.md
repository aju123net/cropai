# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** Uttar Pradesh  
- **Language:** English  
- **Date:** 2017-12-02  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.7 °C  
- Humidity: 74%  
- Rainfall: 43 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.9  
- Organic Carbon: 1.26%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
