# Wheat Rust Guide

- **Crop:** Wheat  
- **Disease:** Rust  
- **Region:** Assam  
- **Language:** Bengali  
- **Date:** 2018-08-13  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.5 °C  
- Humidity: 65%  
- Rainfall: 31 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.9  
- Organic Carbon: 0.56%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
