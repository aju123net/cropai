# Sugarcane Blast Guide

- **Crop:** Sugarcane  
- **Disease:** Blast  
- **Region:** Tamil Nadu  
- **Language:** Tamil  
- **Date:** 2019-04-28  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.9 °C  
- Humidity: 79%  
- Rainfall: 20 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.5  
- Organic Carbon: 1.18%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
