# Potato Rust Guide

- **Crop:** Potato  
- **Disease:** Rust  
- **Region:** West Bengal  
- **Language:** Hindi  
- **Date:** 2025-09-09  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.2 °C  
- Humidity: 81%  
- Rainfall: 24 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.2  
- Organic Carbon: 0.8%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
