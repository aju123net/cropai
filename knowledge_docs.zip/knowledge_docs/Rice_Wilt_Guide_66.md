# Rice Wilt Guide

- **Crop:** Rice  
- **Disease:** Wilt  
- **Region:** Gujarat  
- **Language:** English  
- **Date:** 2020-01-15  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 25.3 °C  
- Humidity: 74%  
- Rainfall: 30 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.6  
- Organic Carbon: 0.62%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
