# Sugarcane Virus Guide

- **Crop:** Sugarcane  
- **Disease:** Virus  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2025-11-19  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.9 °C  
- Humidity: 67%  
- Rainfall: 50 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.76%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
