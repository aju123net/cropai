# Tomato Blight Guide

- **Crop:** Tomato  
- **Disease:** Blight  
- **Region:** Assam  
- **Language:** English  
- **Date:** 2022-01-21  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.3 °C  
- Humidity: 49%  
- Rainfall: 24 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.1  
- Organic Carbon: 1.47%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
