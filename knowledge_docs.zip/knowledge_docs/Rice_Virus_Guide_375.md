# Rice Virus Guide

- **Crop:** Rice  
- **Disease:** Virus  
- **Region:** West Bengal  
- **Language:** Tamil  
- **Date:** 2025-12-25  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.9 °C  
- Humidity: 56%  
- Rainfall: 21 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.8  
- Organic Carbon: 1.74%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
