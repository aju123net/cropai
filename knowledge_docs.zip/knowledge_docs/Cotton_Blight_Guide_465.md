# Cotton Blight Guide

- **Crop:** Cotton  
- **Disease:** Blight  
- **Region:** Karnataka  
- **Language:** English  
- **Date:** 2016-08-29  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.8 °C  
- Humidity: 74%  
- Rainfall: 10 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.95%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
