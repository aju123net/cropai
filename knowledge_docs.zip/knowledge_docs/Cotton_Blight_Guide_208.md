# Cotton Blight Guide

- **Crop:** Cotton  
- **Disease:** Blight  
- **Region:** West Bengal  
- **Language:** English  
- **Date:** 2023-05-10  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.5 °C  
- Humidity: 72%  
- Rainfall: 8 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.6  
- Organic Carbon: 0.55%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
