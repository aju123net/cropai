# Cotton Blast Guide

- **Crop:** Cotton  
- **Disease:** Blast  
- **Region:** Karnataka  
- **Language:** Hindi  
- **Date:** 2019-02-20  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 25.9 °C  
- Humidity: 42%  
- Rainfall: 12 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.8  
- Organic Carbon: 0.86%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
