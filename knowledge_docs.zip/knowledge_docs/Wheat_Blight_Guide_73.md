# Wheat Blight Guide

- **Crop:** Wheat  
- **Disease:** Blight  
- **Region:** Tamil Nadu  
- **Language:** Bengali  
- **Date:** 2026-01-14  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.0 °C  
- Humidity: 53%  
- Rainfall: 43 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.91%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
