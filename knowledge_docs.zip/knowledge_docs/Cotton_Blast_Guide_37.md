# Cotton Blast Guide

- **Crop:** Cotton  
- **Disease:** Blast  
- **Region:** Uttar Pradesh  
- **Language:** Bengali  
- **Date:** 2017-01-27  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.9 °C  
- Humidity: 49%  
- Rainfall: 5 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.5  
- Organic Carbon: 1.89%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
