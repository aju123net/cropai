# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Gujarat  
- **Language:** Hindi  
- **Date:** 2025-09-07  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.1 °C  
- Humidity: 81%  
- Rainfall: 15 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.4  
- Organic Carbon: 0.91%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
