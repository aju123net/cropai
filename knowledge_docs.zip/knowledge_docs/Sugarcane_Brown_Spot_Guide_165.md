# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2018-02-27  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 25.5 °C  
- Humidity: 78%  
- Rainfall: 15 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.78%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
