# Maize Blast Guide

- **Crop:** Maize  
- **Disease:** Blast  
- **Region:** Gujarat  
- **Language:** Bengali  
- **Date:** 2021-02-17  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.3 °C  
- Humidity: 82%  
- Rainfall: 21 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.9  
- Organic Carbon: 1.02%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
