# Cotton Blight Guide

- **Crop:** Cotton  
- **Disease:** Blight  
- **Region:** Karnataka  
- **Language:** Tamil  
- **Date:** 2022-01-09  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.8 °C  
- Humidity: 61%  
- Rainfall: 21 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.06%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
