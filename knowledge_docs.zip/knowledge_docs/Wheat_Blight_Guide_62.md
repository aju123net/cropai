# Wheat Blight Guide

- **Crop:** Wheat  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** English  
- **Date:** 2025-10-01  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.8 °C  
- Humidity: 63%  
- Rainfall: 40 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.8  
- Organic Carbon: 0.66%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
