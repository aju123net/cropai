# Mustard Blast Guide

- **Crop:** Mustard  
- **Disease:** Blast  
- **Region:** Maharashtra  
- **Language:** Tamil  
- **Date:** 2020-08-07  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.3 °C  
- Humidity: 80%  
- Rainfall: 25 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.9  
- Organic Carbon: 0.81%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
