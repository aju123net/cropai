# Maize Virus Guide

- **Crop:** Maize  
- **Disease:** Virus  
- **Region:** Karnataka  
- **Language:** Tamil  
- **Date:** 2017-07-15  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.7 °C  
- Humidity: 49%  
- Rainfall: 49 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.8  
- Organic Carbon: 0.69%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
