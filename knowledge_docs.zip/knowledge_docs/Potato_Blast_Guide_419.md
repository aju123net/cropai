# Potato Blast Guide

- **Crop:** Potato  
- **Disease:** Blast  
- **Region:** Punjab  
- **Language:** Hindi  
- **Date:** 2020-04-29  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.7 °C  
- Humidity: 44%  
- Rainfall: 7 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.95%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
