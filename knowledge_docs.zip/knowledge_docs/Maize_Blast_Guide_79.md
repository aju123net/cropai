# Maize Blast Guide

- **Crop:** Maize  
- **Disease:** Blast  
- **Region:** Gujarat  
- **Language:** Hindi  
- **Date:** 2019-05-11  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 25.8 °C  
- Humidity: 88%  
- Rainfall: 47 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.6  
- Organic Carbon: 0.67%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
