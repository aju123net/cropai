# Tomato Brown Spot Guide

- **Crop:** Tomato  
- **Disease:** Brown Spot  
- **Region:** West Bengal  
- **Language:** Bengali  
- **Date:** 2022-02-02  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.2 °C  
- Humidity: 48%  
- Rainfall: 6 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.04%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
