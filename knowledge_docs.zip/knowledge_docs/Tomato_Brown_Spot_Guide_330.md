# Tomato Brown Spot Guide

- **Crop:** Tomato  
- **Disease:** Brown Spot  
- **Region:** Uttar Pradesh  
- **Language:** Hindi  
- **Date:** 2016-08-04  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.9 °C  
- Humidity: 78%  
- Rainfall: 45 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.2  
- Organic Carbon: 1.78%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
