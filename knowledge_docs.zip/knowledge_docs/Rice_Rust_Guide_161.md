# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** Assam  
- **Language:** Bengali  
- **Date:** 2020-02-13  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.6 °C  
- Humidity: 79%  
- Rainfall: 32 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.7  
- Organic Carbon: 0.99%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
