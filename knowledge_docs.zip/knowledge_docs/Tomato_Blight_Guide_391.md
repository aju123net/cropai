# Tomato Blight Guide

- **Crop:** Tomato  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** Hindi  
- **Date:** 2021-09-03  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.0 °C  
- Humidity: 77%  
- Rainfall: 30 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.0  
- Organic Carbon: 0.86%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
