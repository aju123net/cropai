# Maize Rust Guide

- **Crop:** Maize  
- **Disease:** Rust  
- **Region:** Assam  
- **Language:** Hindi  
- **Date:** 2016-11-02  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.8 °C  
- Humidity: 46%  
- Rainfall: 7 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.1  
- Organic Carbon: 1.97%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
