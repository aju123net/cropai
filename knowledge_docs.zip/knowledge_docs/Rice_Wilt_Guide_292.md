# Rice Wilt Guide

- **Crop:** Rice  
- **Disease:** Wilt  
- **Region:** Gujarat  
- **Language:** English  
- **Date:** 2018-06-13  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.9 °C  
- Humidity: 48%  
- Rainfall: 30 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.2  
- Organic Carbon: 0.52%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
