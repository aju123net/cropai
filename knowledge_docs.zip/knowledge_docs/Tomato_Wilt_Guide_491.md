# Tomato Wilt Guide

- **Crop:** Tomato  
- **Disease:** Wilt  
- **Region:** Maharashtra  
- **Language:** Bengali  
- **Date:** 2026-07-03  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.9 °C  
- Humidity: 40%  
- Rainfall: 50 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.0  
- Organic Carbon: 1.07%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
