# Tomato Brown Spot Guide

- **Crop:** Tomato  
- **Disease:** Brown Spot  
- **Region:** Odisha  
- **Language:** English  
- **Date:** 2017-12-22  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.0 °C  
- Humidity: 77%  
- Rainfall: 32 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.2  
- Organic Carbon: 0.54%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
