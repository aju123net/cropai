# Maize Brown Spot Guide

- **Crop:** Maize  
- **Disease:** Brown Spot  
- **Region:** Uttar Pradesh  
- **Language:** Tamil  
- **Date:** 2022-11-09  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.0 °C  
- Humidity: 56%  
- Rainfall: 13 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.0  
- Organic Carbon: 1.13%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
