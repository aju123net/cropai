# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** Punjab  
- **Language:** Tamil  
- **Date:** 2021-10-21  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 25.8 °C  
- Humidity: 63%  
- Rainfall: 41 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.8  
- Organic Carbon: 0.94%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
