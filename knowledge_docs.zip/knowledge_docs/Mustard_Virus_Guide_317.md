# Mustard Virus Guide

- **Crop:** Mustard  
- **Disease:** Virus  
- **Region:** Gujarat  
- **Language:** Bengali  
- **Date:** 2016-09-07  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.7 °C  
- Humidity: 79%  
- Rainfall: 0 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.93%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
