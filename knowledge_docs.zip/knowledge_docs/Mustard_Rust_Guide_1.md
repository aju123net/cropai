# Mustard Rust Guide

- **Crop:** Mustard  
- **Disease:** Rust  
- **Region:** Punjab  
- **Language:** Hindi  
- **Date:** 2024-04-28  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.4 °C  
- Humidity: 77%  
- Rainfall: 49 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.2  
- Organic Carbon: 0.93%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
