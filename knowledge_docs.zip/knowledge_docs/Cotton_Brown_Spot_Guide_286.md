# Cotton Brown Spot Guide

- **Crop:** Cotton  
- **Disease:** Brown Spot  
- **Region:** Bihar  
- **Language:** Bengali  
- **Date:** 2023-04-12  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 25.1 °C  
- Humidity: 51%  
- Rainfall: 37 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.91%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
