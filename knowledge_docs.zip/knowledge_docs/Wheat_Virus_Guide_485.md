# Wheat Virus Guide

- **Crop:** Wheat  
- **Disease:** Virus  
- **Region:** Maharashtra  
- **Language:** Tamil  
- **Date:** 2020-06-15  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.2 °C  
- Humidity: 44%  
- Rainfall: 41 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.1%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
