# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Karnataka  
- **Language:** Hindi  
- **Date:** 2026-02-24  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.2 °C  
- Humidity: 40%  
- Rainfall: 23 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.05%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
