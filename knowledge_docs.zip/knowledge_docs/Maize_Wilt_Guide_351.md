# Maize Wilt Guide

- **Crop:** Maize  
- **Disease:** Wilt  
- **Region:** Bihar  
- **Language:** Bengali  
- **Date:** 2025-07-21  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.5 °C  
- Humidity: 89%  
- Rainfall: 1 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.6  
- Organic Carbon: 0.75%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
