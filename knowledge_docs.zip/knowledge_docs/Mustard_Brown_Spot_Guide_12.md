# Mustard Brown Spot Guide

- **Crop:** Mustard  
- **Disease:** Brown Spot  
- **Region:** West Bengal  
- **Language:** Tamil  
- **Date:** 2021-06-16  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.1 °C  
- Humidity: 90%  
- Rainfall: 37 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.5%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
