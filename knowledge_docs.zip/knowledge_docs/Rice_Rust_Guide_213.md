# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** West Bengal  
- **Language:** Tamil  
- **Date:** 2017-09-15  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.8 °C  
- Humidity: 52%  
- Rainfall: 41 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.1  
- Organic Carbon: 0.58%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
