# Cotton Blast Guide

- **Crop:** Cotton  
- **Disease:** Blast  
- **Region:** Uttar Pradesh  
- **Language:** English  
- **Date:** 2025-02-24  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.4 °C  
- Humidity: 40%  
- Rainfall: 43 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.2  
- Organic Carbon: 0.97%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
