# Rice Virus Guide

- **Crop:** Rice  
- **Disease:** Virus  
- **Region:** Tamil Nadu  
- **Language:** English  
- **Date:** 2025-08-25  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.5 °C  
- Humidity: 53%  
- Rainfall: 34 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.16%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
