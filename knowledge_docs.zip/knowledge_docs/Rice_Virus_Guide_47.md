# Rice Virus Guide

- **Crop:** Rice  
- **Disease:** Virus  
- **Region:** Bihar  
- **Language:** Tamil  
- **Date:** 2022-12-05  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.2 °C  
- Humidity: 50%  
- Rainfall: 50 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.4  
- Organic Carbon: 0.76%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
