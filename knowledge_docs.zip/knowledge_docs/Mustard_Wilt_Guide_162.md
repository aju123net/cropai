# Mustard Wilt Guide

- **Crop:** Mustard  
- **Disease:** Wilt  
- **Region:** Tamil Nadu  
- **Language:** Hindi  
- **Date:** 2024-10-25  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.5 °C  
- Humidity: 70%  
- Rainfall: 31 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.9  
- Organic Carbon: 0.91%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
