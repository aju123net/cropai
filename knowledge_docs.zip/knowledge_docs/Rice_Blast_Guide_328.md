# Rice Blast Guide

- **Crop:** Rice  
- **Disease:** Blast  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2019-10-18  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.1 °C  
- Humidity: 73%  
- Rainfall: 35 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.2%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
