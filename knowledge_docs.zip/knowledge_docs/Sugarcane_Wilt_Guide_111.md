# Sugarcane Wilt Guide

- **Crop:** Sugarcane  
- **Disease:** Wilt  
- **Region:** Assam  
- **Language:** Bengali  
- **Date:** 2017-02-26  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.0 °C  
- Humidity: 73%  
- Rainfall: 3 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.1  
- Organic Carbon: 1.84%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
