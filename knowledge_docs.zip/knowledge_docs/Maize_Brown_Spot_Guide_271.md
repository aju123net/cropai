# Maize Brown Spot Guide

- **Crop:** Maize  
- **Disease:** Brown Spot  
- **Region:** Odisha  
- **Language:** English  
- **Date:** 2025-11-17  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.2 °C  
- Humidity: 82%  
- Rainfall: 20 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.36%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
