# Potato Brown Spot Guide

- **Crop:** Potato  
- **Disease:** Brown Spot  
- **Region:** Tamil Nadu  
- **Language:** English  
- **Date:** 2017-07-04  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.7 °C  
- Humidity: 73%  
- Rainfall: 33 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.9  
- Organic Carbon: 0.81%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
