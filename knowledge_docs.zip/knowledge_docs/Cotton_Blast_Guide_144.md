# Cotton Blast Guide

- **Crop:** Cotton  
- **Disease:** Blast  
- **Region:** Maharashtra  
- **Language:** Bengali  
- **Date:** 2017-02-16  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.3 °C  
- Humidity: 49%  
- Rainfall: 16 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.4  
- Organic Carbon: 1.84%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
