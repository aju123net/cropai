# Rice Wilt Guide

- **Crop:** Rice  
- **Disease:** Wilt  
- **Region:** Karnataka  
- **Language:** English  
- **Date:** 2023-12-24  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.3 °C  
- Humidity: 65%  
- Rainfall: 23 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.4  
- Organic Carbon: 1.37%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
