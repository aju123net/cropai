# Maize Rust Guide

- **Crop:** Maize  
- **Disease:** Rust  
- **Region:** Tamil Nadu  
- **Language:** Bengali  
- **Date:** 2020-02-29  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.3 °C  
- Humidity: 80%  
- Rainfall: 27 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.2  
- Organic Carbon: 1.31%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
