# Tomato Wilt Guide

- **Crop:** Tomato  
- **Disease:** Wilt  
- **Region:** Tamil Nadu  
- **Language:** Bengali  
- **Date:** 2021-12-29  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.5 °C  
- Humidity: 42%  
- Rainfall: 20 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.09%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
