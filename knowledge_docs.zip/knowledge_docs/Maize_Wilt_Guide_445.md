# Maize Wilt Guide

- **Crop:** Maize  
- **Disease:** Wilt  
- **Region:** Maharashtra  
- **Language:** Hindi  
- **Date:** 2019-03-31  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.0 °C  
- Humidity: 48%  
- Rainfall: 31 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.89%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
