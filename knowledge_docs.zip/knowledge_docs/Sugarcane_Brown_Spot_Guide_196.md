# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Punjab  
- **Language:** Hindi  
- **Date:** 2016-09-19  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.4 °C  
- Humidity: 51%  
- Rainfall: 31 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.88%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
