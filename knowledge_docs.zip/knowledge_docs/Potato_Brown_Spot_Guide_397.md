# Potato Brown Spot Guide

- **Crop:** Potato  
- **Disease:** Brown Spot  
- **Region:** Punjab  
- **Language:** English  
- **Date:** 2024-10-01  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 28.9 °C  
- Humidity: 43%  
- Rainfall: 22 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.2  
- Organic Carbon: 0.5%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
