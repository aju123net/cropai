# Wheat Blight Guide

- **Crop:** Wheat  
- **Disease:** Blight  
- **Region:** Uttar Pradesh  
- **Language:** Hindi  
- **Date:** 2020-09-29  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.9 °C  
- Humidity: 57%  
- Rainfall: 23 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.3  
- Organic Carbon: 0.97%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
