# Cotton Brown Spot Guide

- **Crop:** Cotton  
- **Disease:** Brown Spot  
- **Region:** Bihar  
- **Language:** Hindi  
- **Date:** 2017-01-06  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.7 °C  
- Humidity: 77%  
- Rainfall: 20 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.0  
- Organic Carbon: 1.14%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
