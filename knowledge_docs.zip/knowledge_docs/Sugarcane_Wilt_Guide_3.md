# Sugarcane Wilt Guide

- **Crop:** Sugarcane  
- **Disease:** Wilt  
- **Region:** Tamil Nadu  
- **Language:** Hindi  
- **Date:** 2026-04-30  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.0 °C  
- Humidity: 46%  
- Rainfall: 39 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.1  
- Organic Carbon: 1.94%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
