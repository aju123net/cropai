# Sugarcane Virus Guide

- **Crop:** Sugarcane  
- **Disease:** Virus  
- **Region:** Tamil Nadu  
- **Language:** English  
- **Date:** 2017-06-11  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.7 °C  
- Humidity: 62%  
- Rainfall: 18 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.99%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
