# Wheat Virus Guide

- **Crop:** Wheat  
- **Disease:** Virus  
- **Region:** Gujarat  
- **Language:** Bengali  
- **Date:** 2018-08-26  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.9 °C  
- Humidity: 53%  
- Rainfall: 27 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.0  
- Organic Carbon: 1.55%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
