# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Uttar Pradesh  
- **Language:** English  
- **Date:** 2023-05-15  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.4 °C  
- Humidity: 69%  
- Rainfall: 49 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.0  
- Organic Carbon: 1.1%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
