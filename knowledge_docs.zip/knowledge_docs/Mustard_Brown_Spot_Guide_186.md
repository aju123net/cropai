# Mustard Brown Spot Guide

- **Crop:** Mustard  
- **Disease:** Brown Spot  
- **Region:** Odisha  
- **Language:** English  
- **Date:** 2016-09-07  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.8 °C  
- Humidity: 56%  
- Rainfall: 20 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.38%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
