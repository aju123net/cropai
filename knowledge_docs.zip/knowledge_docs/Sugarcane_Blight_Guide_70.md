# Sugarcane Blight Guide

- **Crop:** Sugarcane  
- **Disease:** Blight  
- **Region:** Assam  
- **Language:** Hindi  
- **Date:** 2025-01-31  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.5 °C  
- Humidity: 85%  
- Rainfall: 46 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.84%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
