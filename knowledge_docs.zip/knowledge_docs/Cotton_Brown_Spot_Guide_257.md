# Cotton Brown Spot Guide

- **Crop:** Cotton  
- **Disease:** Brown Spot  
- **Region:** Gujarat  
- **Language:** Bengali  
- **Date:** 2022-09-11  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.5 °C  
- Humidity: 63%  
- Rainfall: 42 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.15%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
