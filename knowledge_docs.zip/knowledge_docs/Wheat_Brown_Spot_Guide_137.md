# Wheat Brown Spot Guide

- **Crop:** Wheat  
- **Disease:** Brown Spot  
- **Region:** Karnataka  
- **Language:** Bengali  
- **Date:** 2021-01-17  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.2 °C  
- Humidity: 57%  
- Rainfall: 32 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.6  
- Organic Carbon: 0.61%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
