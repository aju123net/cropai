# Tomato Rust Guide

- **Crop:** Tomato  
- **Disease:** Rust  
- **Region:** Maharashtra  
- **Language:** Hindi  
- **Date:** 2018-10-12  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.9 °C  
- Humidity: 59%  
- Rainfall: 43 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.2  
- Organic Carbon: 1.68%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
