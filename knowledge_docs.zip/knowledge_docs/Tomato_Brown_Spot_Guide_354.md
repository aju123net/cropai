# Tomato Brown Spot Guide

- **Crop:** Tomato  
- **Disease:** Brown Spot  
- **Region:** Bihar  
- **Language:** Bengali  
- **Date:** 2025-09-17  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.7 °C  
- Humidity: 87%  
- Rainfall: 41 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.24%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
