# Rice Blight Guide

- **Crop:** Rice  
- **Disease:** Blight  
- **Region:** Karnataka  
- **Language:** English  
- **Date:** 2021-06-06  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.8 °C  
- Humidity: 83%  
- Rainfall: 21 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.6  
- Organic Carbon: 0.98%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
