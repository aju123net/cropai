# Cotton Virus Guide

- **Crop:** Cotton  
- **Disease:** Virus  
- **Region:** Bihar  
- **Language:** English  
- **Date:** 2020-12-09  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.9 °C  
- Humidity: 54%  
- Rainfall: 23 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.0  
- Organic Carbon: 0.84%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
