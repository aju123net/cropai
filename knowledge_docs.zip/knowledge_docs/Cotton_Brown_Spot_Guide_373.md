# Cotton Brown Spot Guide

- **Crop:** Cotton  
- **Disease:** Brown Spot  
- **Region:** West Bengal  
- **Language:** English  
- **Date:** 2025-05-16  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.9 °C  
- Humidity: 73%  
- Rainfall: 45 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.06%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
