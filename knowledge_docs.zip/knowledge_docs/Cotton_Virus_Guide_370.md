# Cotton Virus Guide

- **Crop:** Cotton  
- **Disease:** Virus  
- **Region:** Assam  
- **Language:** English  
- **Date:** 2025-05-07  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.0 °C  
- Humidity: 50%  
- Rainfall: 50 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.0  
- Organic Carbon: 0.99%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
