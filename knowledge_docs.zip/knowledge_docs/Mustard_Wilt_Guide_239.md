# Mustard Wilt Guide

- **Crop:** Mustard  
- **Disease:** Wilt  
- **Region:** Maharashtra  
- **Language:** English  
- **Date:** 2018-12-11  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.3 °C  
- Humidity: 41%  
- Rainfall: 11 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.6%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
