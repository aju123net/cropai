# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** Assam  
- **Language:** English  
- **Date:** 2020-06-20  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.7 °C  
- Humidity: 72%  
- Rainfall: 44 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.08%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
