# Potato Wilt Guide

- **Crop:** Potato  
- **Disease:** Wilt  
- **Region:** West Bengal  
- **Language:** Hindi  
- **Date:** 2019-03-20  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.5 °C  
- Humidity: 85%  
- Rainfall: 0 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.4  
- Organic Carbon: 1.99%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
