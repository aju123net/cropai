# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Uttar Pradesh  
- **Language:** Tamil  
- **Date:** 2018-02-14  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.0 °C  
- Humidity: 61%  
- Rainfall: 31 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.78%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
