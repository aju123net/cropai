# Mustard Virus Guide

- **Crop:** Mustard  
- **Disease:** Virus  
- **Region:** West Bengal  
- **Language:** Bengali  
- **Date:** 2021-04-18  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.0 °C  
- Humidity: 55%  
- Rainfall: 3 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.7  
- Organic Carbon: 1.28%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
