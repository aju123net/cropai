# Rice Virus Guide

- **Crop:** Rice  
- **Disease:** Virus  
- **Region:** Gujarat  
- **Language:** Bengali  
- **Date:** 2016-10-28  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.8 °C  
- Humidity: 90%  
- Rainfall: 12 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.0  
- Organic Carbon: 0.83%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
