# Sugarcane Wilt Guide

- **Crop:** Sugarcane  
- **Disease:** Wilt  
- **Region:** Tamil Nadu  
- **Language:** English  
- **Date:** 2018-01-26  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.7 °C  
- Humidity: 78%  
- Rainfall: 27 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.9  
- Organic Carbon: 1.81%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
