# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Assam  
- **Language:** English  
- **Date:** 2017-12-13  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.6 °C  
- Humidity: 82%  
- Rainfall: 12 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.5  
- Organic Carbon: 0.68%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
