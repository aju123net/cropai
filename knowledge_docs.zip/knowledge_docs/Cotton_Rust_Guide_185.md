# Cotton Rust Guide

- **Crop:** Cotton  
- **Disease:** Rust  
- **Region:** Karnataka  
- **Language:** Tamil  
- **Date:** 2023-07-11  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.1 °C  
- Humidity: 48%  
- Rainfall: 21 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.5  
- Organic Carbon: 1.4%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
