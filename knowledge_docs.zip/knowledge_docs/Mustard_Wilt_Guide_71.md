# Mustard Wilt Guide

- **Crop:** Mustard  
- **Disease:** Wilt  
- **Region:** Karnataka  
- **Language:** English  
- **Date:** 2023-11-09  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.8 °C  
- Humidity: 49%  
- Rainfall: 50 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.57%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
