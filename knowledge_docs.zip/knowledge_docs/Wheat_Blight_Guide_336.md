# Wheat Blight Guide

- **Crop:** Wheat  
- **Disease:** Blight  
- **Region:** Bihar  
- **Language:** English  
- **Date:** 2018-11-27  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.8 °C  
- Humidity: 70%  
- Rainfall: 17 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.5  
- Organic Carbon: 1.44%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
