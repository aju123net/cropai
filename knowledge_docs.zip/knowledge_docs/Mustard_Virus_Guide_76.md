# Mustard Virus Guide

- **Crop:** Mustard  
- **Disease:** Virus  
- **Region:** Uttar Pradesh  
- **Language:** Bengali  
- **Date:** 2025-02-08  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.8 °C  
- Humidity: 57%  
- Rainfall: 19 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.45%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
