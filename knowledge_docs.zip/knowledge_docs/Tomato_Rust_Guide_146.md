# Tomato Rust Guide

- **Crop:** Tomato  
- **Disease:** Rust  
- **Region:** Tamil Nadu  
- **Language:** Tamil  
- **Date:** 2026-01-26  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.6 °C  
- Humidity: 48%  
- Rainfall: 49 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.9%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
