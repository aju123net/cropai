# Potato Rust Guide

- **Crop:** Potato  
- **Disease:** Rust  
- **Region:** Maharashtra  
- **Language:** Hindi  
- **Date:** 2023-08-11  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.2 °C  
- Humidity: 74%  
- Rainfall: 24 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.61%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
