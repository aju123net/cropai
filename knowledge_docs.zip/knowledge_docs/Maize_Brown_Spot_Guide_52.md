# Maize Brown Spot Guide

- **Crop:** Maize  
- **Disease:** Brown Spot  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2017-11-24  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.4 °C  
- Humidity: 80%  
- Rainfall: 49 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.81%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
