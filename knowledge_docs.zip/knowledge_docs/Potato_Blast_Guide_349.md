# Potato Blast Guide

- **Crop:** Potato  
- **Disease:** Blast  
- **Region:** Odisha  
- **Language:** Bengali  
- **Date:** 2022-03-17  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.1 °C  
- Humidity: 50%  
- Rainfall: 32 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.0%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
