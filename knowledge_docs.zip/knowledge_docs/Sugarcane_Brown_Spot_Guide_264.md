# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Tamil Nadu  
- **Language:** English  
- **Date:** 2026-01-23  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.0 °C  
- Humidity: 88%  
- Rainfall: 32 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.2  
- Organic Carbon: 1.31%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
