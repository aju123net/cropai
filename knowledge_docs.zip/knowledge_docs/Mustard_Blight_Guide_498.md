# Mustard Blight Guide

- **Crop:** Mustard  
- **Disease:** Blight  
- **Region:** Odisha  
- **Language:** Tamil  
- **Date:** 2024-08-27  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.6 °C  
- Humidity: 77%  
- Rainfall: 19 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.1  
- Organic Carbon: 1.56%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
