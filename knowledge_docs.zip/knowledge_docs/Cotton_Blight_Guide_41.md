# Cotton Blight Guide

- **Crop:** Cotton  
- **Disease:** Blight  
- **Region:** Uttar Pradesh  
- **Language:** Hindi  
- **Date:** 2022-09-09  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.6 °C  
- Humidity: 49%  
- Rainfall: 32 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.2  
- Organic Carbon: 1.7%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
