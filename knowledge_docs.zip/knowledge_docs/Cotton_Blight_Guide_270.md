# Cotton Blight Guide

- **Crop:** Cotton  
- **Disease:** Blight  
- **Region:** West Bengal  
- **Language:** Bengali  
- **Date:** 2025-03-16  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.3 °C  
- Humidity: 44%  
- Rainfall: 21 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.6  
- Organic Carbon: 1.28%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
