# Rice Blight Guide

- **Crop:** Rice  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** Bengali  
- **Date:** 2017-06-02  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 28.3 °C  
- Humidity: 50%  
- Rainfall: 4 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.6  
- Organic Carbon: 1.32%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
