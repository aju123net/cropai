# Rice Blast Guide

- **Crop:** Rice  
- **Disease:** Blast  
- **Region:** Bihar  
- **Language:** English  
- **Date:** 2017-08-17  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 21.8 °C  
- Humidity: 64%  
- Rainfall: 34 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.8  
- Organic Carbon: 1.55%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
