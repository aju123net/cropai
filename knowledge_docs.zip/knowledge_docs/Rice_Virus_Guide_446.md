# Rice Virus Guide

- **Crop:** Rice  
- **Disease:** Virus  
- **Region:** Karnataka  
- **Language:** Bengali  
- **Date:** 2025-02-08  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.1 °C  
- Humidity: 54%  
- Rainfall: 35 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.7  
- Organic Carbon: 0.75%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
