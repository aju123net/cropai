# Cotton Rust Guide

- **Crop:** Cotton  
- **Disease:** Rust  
- **Region:** Punjab  
- **Language:** English  
- **Date:** 2018-07-27  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.6 °C  
- Humidity: 85%  
- Rainfall: 16 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.3  
- Organic Carbon: 0.57%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
