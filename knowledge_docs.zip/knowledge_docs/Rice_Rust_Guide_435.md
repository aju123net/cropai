# Rice Rust Guide

- **Crop:** Rice  
- **Disease:** Rust  
- **Region:** Maharashtra  
- **Language:** English  
- **Date:** 2020-09-22  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.7 °C  
- Humidity: 46%  
- Rainfall: 1 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.37%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
