# Tomato Blight Guide

- **Crop:** Tomato  
- **Disease:** Blight  
- **Region:** Tamil Nadu  
- **Language:** Tamil  
- **Date:** 2020-04-16  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.2 °C  
- Humidity: 86%  
- Rainfall: 24 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.66%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
