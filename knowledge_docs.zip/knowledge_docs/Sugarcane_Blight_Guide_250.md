# Sugarcane Blight Guide

- **Crop:** Sugarcane  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** Tamil  
- **Date:** 2023-03-02  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 35.0 °C  
- Humidity: 63%  
- Rainfall: 34 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.26%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
