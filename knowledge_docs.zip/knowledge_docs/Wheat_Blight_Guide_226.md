# Wheat Blight Guide

- **Crop:** Wheat  
- **Disease:** Blight  
- **Region:** Odisha  
- **Language:** Tamil  
- **Date:** 2022-03-29  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.4 °C  
- Humidity: 58%  
- Rainfall: 41 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.1%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
