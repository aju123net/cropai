# Tomato Wilt Guide

- **Crop:** Tomato  
- **Disease:** Wilt  
- **Region:** Punjab  
- **Language:** Tamil  
- **Date:** 2019-02-14  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.2 °C  
- Humidity: 77%  
- Rainfall: 43 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.4%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
