# Maize Rust Guide

- **Crop:** Maize  
- **Disease:** Rust  
- **Region:** Bihar  
- **Language:** Tamil  
- **Date:** 2020-07-24  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.0 °C  
- Humidity: 89%  
- Rainfall: 35 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.8  
- Organic Carbon: 1.17%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
