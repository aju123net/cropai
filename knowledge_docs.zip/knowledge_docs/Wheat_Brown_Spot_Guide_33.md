# Wheat Brown Spot Guide

- **Crop:** Wheat  
- **Disease:** Brown Spot  
- **Region:** West Bengal  
- **Language:** English  
- **Date:** 2025-04-23  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.2 °C  
- Humidity: 59%  
- Rainfall: 35 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.1%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
