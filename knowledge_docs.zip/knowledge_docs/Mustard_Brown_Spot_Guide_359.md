# Mustard Brown Spot Guide

- **Crop:** Mustard  
- **Disease:** Brown Spot  
- **Region:** West Bengal  
- **Language:** English  
- **Date:** 2021-10-09  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.6 °C  
- Humidity: 45%  
- Rainfall: 21 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.75%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
