# Mustard Blight Guide

- **Crop:** Mustard  
- **Disease:** Blight  
- **Region:** West Bengal  
- **Language:** Bengali  
- **Date:** 2019-06-02  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.7 °C  
- Humidity: 76%  
- Rainfall: 1 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.6  
- Organic Carbon: 1.42%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
