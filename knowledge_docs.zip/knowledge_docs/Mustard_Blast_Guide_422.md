# Mustard Blast Guide

- **Crop:** Mustard  
- **Disease:** Blast  
- **Region:** Maharashtra  
- **Language:** Hindi  
- **Date:** 2020-10-06  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.2 °C  
- Humidity: 47%  
- Rainfall: 13 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.7  
- Organic Carbon: 1.26%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
