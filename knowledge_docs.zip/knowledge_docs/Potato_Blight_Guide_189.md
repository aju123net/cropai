# Potato Blight Guide

- **Crop:** Potato  
- **Disease:** Blight  
- **Region:** West Bengal  
- **Language:** Tamil  
- **Date:** 2021-04-18  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 29.2 °C  
- Humidity: 75%  
- Rainfall: 42 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.7  
- Organic Carbon: 0.81%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
