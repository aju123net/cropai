# Tomato Blast Guide

- **Crop:** Tomato  
- **Disease:** Blast  
- **Region:** Bihar  
- **Language:** English  
- **Date:** 2016-09-28  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.3 °C  
- Humidity: 43%  
- Rainfall: 24 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.1  
- Organic Carbon: 0.73%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
