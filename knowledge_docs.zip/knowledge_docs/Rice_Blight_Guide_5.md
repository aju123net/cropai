# Rice Blight Guide

- **Crop:** Rice  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** Hindi  
- **Date:** 2018-03-19  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 20.1 °C  
- Humidity: 63%  
- Rainfall: 47 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.6  
- Organic Carbon: 0.54%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
