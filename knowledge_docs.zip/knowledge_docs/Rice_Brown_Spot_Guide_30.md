# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Maharashtra  
- **Language:** Tamil  
- **Date:** 2018-05-12  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.1 °C  
- Humidity: 84%  
- Rainfall: 33 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.3  
- Organic Carbon: 1.78%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
