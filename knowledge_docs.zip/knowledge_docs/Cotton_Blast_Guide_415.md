# Cotton Blast Guide

- **Crop:** Cotton  
- **Disease:** Blast  
- **Region:** Karnataka  
- **Language:** English  
- **Date:** 2021-08-11  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.0 °C  
- Humidity: 49%  
- Rainfall: 23 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.8  
- Organic Carbon: 1.55%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
