# Potato Blast Guide

- **Crop:** Potato  
- **Disease:** Blast  
- **Region:** Assam  
- **Language:** Tamil  
- **Date:** 2024-02-29  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.0 °C  
- Humidity: 49%  
- Rainfall: 49 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.57%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
