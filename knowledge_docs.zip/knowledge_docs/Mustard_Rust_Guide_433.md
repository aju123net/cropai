# Mustard Rust Guide

- **Crop:** Mustard  
- **Disease:** Rust  
- **Region:** West Bengal  
- **Language:** English  
- **Date:** 2023-04-06  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 28.6 °C  
- Humidity: 82%  
- Rainfall: 18 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.2  
- Organic Carbon: 1.64%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
