# Cotton Blight Guide

- **Crop:** Cotton  
- **Disease:** Blight  
- **Region:** Gujarat  
- **Language:** English  
- **Date:** 2019-05-04  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.8 °C  
- Humidity: 68%  
- Rainfall: 38 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.0  
- Organic Carbon: 0.87%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
