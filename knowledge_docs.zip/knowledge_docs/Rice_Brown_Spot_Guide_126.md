# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Punjab  
- **Language:** Tamil  
- **Date:** 2023-05-12  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 22.3 °C  
- Humidity: 52%  
- Rainfall: 17 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.29%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
