# Wheat Brown Spot Guide

- **Crop:** Wheat  
- **Disease:** Brown Spot  
- **Region:** Tamil Nadu  
- **Language:** Tamil  
- **Date:** 2025-07-22  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.8 °C  
- Humidity: 72%  
- Rainfall: 42 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.9  
- Organic Carbon: 1.79%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
