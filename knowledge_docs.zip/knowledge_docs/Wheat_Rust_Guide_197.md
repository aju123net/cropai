# Wheat Rust Guide

- **Crop:** Wheat  
- **Disease:** Rust  
- **Region:** Gujarat  
- **Language:** English  
- **Date:** 2025-07-12  

## Symptoms
- Farmers observe stunted growth and poor grain filling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 34.5 °C  
- Humidity: 58%  
- Rainfall: 41 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.2  
- Organic Carbon: 0.89%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
