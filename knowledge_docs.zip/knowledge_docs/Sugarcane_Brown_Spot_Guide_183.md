# Sugarcane Brown Spot Guide

- **Crop:** Sugarcane  
- **Disease:** Brown Spot  
- **Region:** Assam  
- **Language:** Tamil  
- **Date:** 2024-03-22  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.9 °C  
- Humidity: 80%  
- Rainfall: 45 mm  
- Fungal Risk: High

## Soil Profile
- pH: 5.6  
- Organic Carbon: 1.22%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
