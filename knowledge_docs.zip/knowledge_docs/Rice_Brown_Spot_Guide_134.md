# Rice Brown Spot Guide

- **Crop:** Rice  
- **Disease:** Brown Spot  
- **Region:** Karnataka  
- **Language:** Hindi  
- **Date:** 2023-04-03  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 23.8 °C  
- Humidity: 66%  
- Rainfall: 14 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 7.3  
- Organic Carbon: 0.7%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
