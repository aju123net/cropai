# Wheat Wilt Guide

- **Crop:** Wheat  
- **Disease:** Wilt  
- **Region:** Gujarat  
- **Language:** Hindi  
- **Date:** 2025-09-27  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 35.0 °C  
- Humidity: 86%  
- Rainfall: 21 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.3  
- Organic Carbon: 0.91%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
