# Wheat Blast Guide

- **Crop:** Wheat  
- **Disease:** Blast  
- **Region:** Maharashtra  
- **Language:** Tamil  
- **Date:** 2024-06-17  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.7 °C  
- Humidity: 64%  
- Rainfall: 10 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.3  
- Organic Carbon: 1.6%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
