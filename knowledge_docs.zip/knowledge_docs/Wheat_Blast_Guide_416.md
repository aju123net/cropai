# Wheat Blast Guide

- **Crop:** Wheat  
- **Disease:** Blast  
- **Region:** West Bengal  
- **Language:** Hindi  
- **Date:** 2023-09-19  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.6 °C  
- Humidity: 82%  
- Rainfall: 21 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.41%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
