# Potato Blight Guide

- **Crop:** Potato  
- **Disease:** Blight  
- **Region:** Maharashtra  
- **Language:** English  
- **Date:** 2025-11-23  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.4 °C  
- Humidity: 41%  
- Rainfall: 32 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.11%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
