# Potato Blast Guide

- **Crop:** Potato  
- **Disease:** Blast  
- **Region:** Maharashtra  
- **Language:** Bengali  
- **Date:** 2020-01-30  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.4 °C  
- Humidity: 58%  
- Rainfall: 46 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.9  
- Organic Carbon: 1.54%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
