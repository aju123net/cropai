# Maize Rust Guide

- **Crop:** Maize  
- **Disease:** Rust  
- **Region:** Punjab  
- **Language:** Tamil  
- **Date:** 2024-06-24  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.0 °C  
- Humidity: 63%  
- Rainfall: 4 mm  
- Fungal Risk: High

## Soil Profile
- pH: 6.1  
- Organic Carbon: 0.87%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
