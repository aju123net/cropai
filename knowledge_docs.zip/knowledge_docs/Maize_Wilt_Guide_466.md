# Maize Wilt Guide

- **Crop:** Maize  
- **Disease:** Wilt  
- **Region:** Tamil Nadu  
- **Language:** Bengali  
- **Date:** 2019-10-20  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.8 °C  
- Humidity: 86%  
- Rainfall: 42 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.52%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
