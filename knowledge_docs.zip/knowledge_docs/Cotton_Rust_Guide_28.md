# Cotton Rust Guide

- **Crop:** Cotton  
- **Disease:** Rust  
- **Region:** West Bengal  
- **Language:** Tamil  
- **Date:** 2026-01-04  

## Symptoms
- Farmers observe leaf blight with yellow halos in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 27.3 °C  
- Humidity: 78%  
- Rainfall: 39 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.3  
- Organic Carbon: 0.63%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
