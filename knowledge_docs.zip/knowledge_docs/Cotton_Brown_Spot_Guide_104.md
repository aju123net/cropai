# Cotton Brown Spot Guide

- **Crop:** Cotton  
- **Disease:** Brown Spot  
- **Region:** Odisha  
- **Language:** English  
- **Date:** 2020-11-04  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 33.7 °C  
- Humidity: 42%  
- Rainfall: 14 mm  
- Fungal Risk: High

## Soil Profile
- pH: 7.4  
- Organic Carbon: 0.6%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
