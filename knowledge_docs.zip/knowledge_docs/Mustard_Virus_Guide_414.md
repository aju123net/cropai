# Mustard Virus Guide

- **Crop:** Mustard  
- **Disease:** Virus  
- **Region:** Tamil Nadu  
- **Language:** Hindi  
- **Date:** 2021-10-29  

## Symptoms
- Farmers observe black spots on fruit surfaces in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 26.7 °C  
- Humidity: 81%  
- Rainfall: 34 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.4  
- Organic Carbon: 1.36%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
