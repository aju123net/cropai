# Sugarcane Blight Guide

- **Crop:** Sugarcane  
- **Disease:** Blight  
- **Region:** West Bengal  
- **Language:** Bengali  
- **Date:** 2024-03-18  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 32.7 °C  
- Humidity: 78%  
- Rainfall: 50 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 6.6  
- Organic Carbon: 1.23%  
- Drainage: Poor

*This is synthetic historical guidance for simulation and indexing purposes.*
