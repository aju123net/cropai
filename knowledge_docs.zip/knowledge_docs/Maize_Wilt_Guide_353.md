# Maize Wilt Guide

- **Crop:** Maize  
- **Disease:** Wilt  
- **Region:** Maharashtra  
- **Language:** Hindi  
- **Date:** 2019-12-06  

## Symptoms
- Farmers observe powdery white patches on leaves in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 31.5 °C  
- Humidity: 52%  
- Rainfall: 47 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.0  
- Organic Carbon: 0.99%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
