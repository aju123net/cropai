# Tomato Brown Spot Guide

- **Crop:** Tomato  
- **Disease:** Brown Spot  
- **Region:** Uttar Pradesh  
- **Language:** Tamil  
- **Date:** 2019-11-23  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 28.8 °C  
- Humidity: 47%  
- Rainfall: 2 mm  
- Fungal Risk: Moderate

## Soil Profile
- pH: 5.5  
- Organic Carbon: 1.35%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
