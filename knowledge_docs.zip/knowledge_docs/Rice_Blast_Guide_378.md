# Rice Blast Guide

- **Crop:** Rice  
- **Disease:** Blast  
- **Region:** Tamil Nadu  
- **Language:** Hindi  
- **Date:** 2024-05-02  

## Symptoms
- Farmers observe yellowing leaves with brown lesions in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 24.5 °C  
- Humidity: 46%  
- Rainfall: 36 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 7.0  
- Organic Carbon: 1.85%  
- Drainage: Good

*This is synthetic historical guidance for simulation and indexing purposes.*
