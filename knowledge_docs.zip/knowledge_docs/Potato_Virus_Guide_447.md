# Potato Virus Guide

- **Crop:** Potato  
- **Disease:** Virus  
- **Region:** Odisha  
- **Language:** English  
- **Date:** 2016-08-21  

## Symptoms
- Farmers observe wilting stems and leaf curling in affected plants.

## Causes
- Environmental or biological triggers such as humidity, poor drainage, or infected seed.

## Preventive Measures
- Use certified seed, maintain proper spacing, and ensure balanced nutrition.
- Improve field drainage and avoid waterlogging.

## Treatment
- Apply locally approved fungicides or pesticides following label instructions.
- Remove infected residue and prefer resistant varieties in the next cycle.

## Monitoring
- Inspect fields weekly during humid periods.
- Record disease incidence and adjust management practices accordingly.

## Weather Context
- Temperature: 30.7 °C  
- Humidity: 77%  
- Rainfall: 24 mm  
- Fungal Risk: Low

## Soil Profile
- pH: 5.5  
- Organic Carbon: 1.87%  
- Drainage: Moderate

*This is synthetic historical guidance for simulation and indexing purposes.*
