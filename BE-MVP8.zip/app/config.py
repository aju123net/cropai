from __future__ import annotations

import os
from pathlib import Path

from dotenv import load_dotenv

BACKEND_DIR = Path(__file__).resolve().parents[1]
PROJECT_DIR = BACKEND_DIR.parent

# Prefer backend/.env, while still allowing a project-root .env when present.
load_dotenv(PROJECT_DIR / ".env")
load_dotenv(BACKEND_DIR / ".env", override=True)


def _env(name: str, default: str = "") -> str:
    value = os.getenv(name)
    if value is None or value.strip() == "":
        return default
    return value.strip()


def _env_bool(name: str, default: bool = False) -> bool:
    value = _env(name, "true" if default else "false")
    return value.lower() in {"1", "true", "yes", "on"}


APP_NAME = "KrishiSaarthi AI"
API_PREFIX = "/api/v1"
DATABASE_URL = _env(
    "DATABASE_URL",
    f"sqlite:///{BACKEND_DIR / 'krishisaarthi.db'}",
)

# Keep the original application environment-variable names.
API_ENDPOINT = _env("API_ENDPOINT", "https://genailab.tcs.in/")
if not API_ENDPOINT.endswith("/"):
    API_ENDPOINT += "/"

API_KEY = _env("API_KEY")
API_VERIFY_SSL = _env_bool("API_VERIFY_SSL", default=False)
API_TIMEOUT_SECONDS = float(_env("API_TIMEOUT_SECONDS", "120"))
MOCK_LLM = _env_bool("MOCK_LLM", default=True)

TEXT_MODEL = _env(
    "TEXT_MODEL",
    "azure/genailab-maas-gpt-4.1-mini",
)
VISION_MODEL = _env(
    "VISION_MODEL",
    "azure_ai/genailab-maas-Llama-3.2-90B-Vision-Instruct",
)
EMBEDDING_MODEL = _env(
    "EMBEDDING_MODEL",
    "azure/genailab-maas-text-embedding-3-large",
)
WHISPER_MODEL = _env(
    "WHISPER_MODEL",
    "azure/genailab-maas-whisper",
)

AVAILABLE_MODELS = [
    model_name.strip()
    for model_name in _env("AVAILABLE_MODELS", TEXT_MODEL).split(",")
    if model_name.strip()
]

MAX_UPLOAD_MB = int(_env("MAX_UPLOAD_MB", "8"))
WEATHER_MODE = _env("WEATHER_MODE", "auto")
FRONTEND_ORIGINS = [
    origin.strip()
    for origin in _env(
        "FRONTEND_ORIGINS",
        "http://localhost:5173,http://127.0.0.1:5173",
    ).split(",")
    if origin.strip()
]

UPLOAD_DIR = BACKEND_DIR / "uploads"
IMAGE_DIR = UPLOAD_DIR / "images"
SOIL_REPORT_DIR = UPLOAD_DIR / "soil_reports"
KNOWLEDGE_UPLOAD_DIR = UPLOAD_DIR / "knowledge"
CHROMA_DIR = BACKEND_DIR / "chroma_index"

# Notebook-compatible local tokenizer cache. A relative value is resolved
# from the backend directory, regardless of the shell's current directory.
_cache_dir_value = _env("TIKTOKEN_CACHE_DIR", "tiktoken_cache")
TIKTOKEN_CACHE_DIR = Path(_cache_dir_value).expanduser()
if not TIKTOKEN_CACHE_DIR.is_absolute():
    TIKTOKEN_CACHE_DIR = BACKEND_DIR / TIKTOKEN_CACHE_DIR
TIKTOKEN_CACHE_DIR = TIKTOKEN_CACHE_DIR.resolve()

TIKTOKEN_CACHE_FILE = _env(
    "TIKTOKEN_CACHE_FILE",
    "9b5ad71b2ce5302211f9c61530b329a4922fc6a4",
)

# This must be set before OpenAIEmbeddings performs tokenisation.
os.environ["TIKTOKEN_CACHE_DIR"] = str(TIKTOKEN_CACHE_DIR)

for folder in (
    UPLOAD_DIR,
    IMAGE_DIR,
    SOIL_REPORT_DIR,
    KNOWLEDGE_UPLOAD_DIR,
    CHROMA_DIR,
    TIKTOKEN_CACHE_DIR,
):
    folder.mkdir(parents=True, exist_ok=True)
