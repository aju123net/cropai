from sqlalchemy.orm import Session

from .catalog import SEED_KNOWLEDGE
from .models import (
    AdvisoryCase,
    KnowledgeChunk,
    KnowledgeDocument,
    ModelSetting,
    PromptSetting,
)
from .services import DEFAULT_MODEL_SETTINGS, DEFAULT_PROMPTS, chunk_text


def _ensure_seed_knowledge(db: Session) -> int:
    """Insert every missing seed document and ensure its SQLite chunks exist.

    The previous implementation checked only whether the table contained at
    least one document. If startup was interrupted after the first Tomato
    document, all later restarts treated the partially seeded database as
    complete. This function is idempotent per seed document.
    """
    added = 0
    for title, crop, disease, content in SEED_KNOWLEDGE:
        document = (
            db.query(KnowledgeDocument)
            .filter(
                KnowledgeDocument.title == title,
                KnowledgeDocument.crop == crop,
                KnowledgeDocument.disease == disease,
            )
            .first()
        )
        if not document:
            document = KnowledgeDocument(
                title=title,
                crop=crop,
                disease=disease,
                language="English",
                region="All",
                content=content,
            )
            db.add(document)
            db.flush()
            added += 1

        existing_chunks = (
            db.query(KnowledgeChunk)
            .filter(KnowledgeChunk.document_id == document.id)
            .count()
        )
        if existing_chunks == 0:
            for idx, chunk in enumerate(chunk_text(document.content, size=1000, overlap=150)):
                db.add(
                    KnowledgeChunk(
                        document_id=document.id,
                        chunk_index=idx,
                        content=chunk,
                    )
                )

    db.commit()
    return added


def seed_database(db: Session):
    for key, value in DEFAULT_PROMPTS.items():
        if not db.query(PromptSetting).filter_by(key=key).first():
            db.add(PromptSetting(key=key, value=value))

    for key, value in DEFAULT_MODEL_SETTINGS.items():
        if not db.query(ModelSetting).filter_by(key=key).first():
            db.add(ModelSetting(key=key, value=str(value)))

    db.commit()

    # Seed SQLite only. Chroma is rebuilt lazily on the first retrieval when its
    # document/chunk signature differs from SQLite. This avoids partial indexes
    # and repeated embedding API calls during application startup.
    _ensure_seed_knowledge(db)

    if db.query(AdvisoryCase).count() == 0:
        samples = [
            AdvisoryCase(
                owner_username="farmer",
                farmer_name="Ramesh Farmer",
                crop="Tomato",
                variety="Pusa Ruby",
                growth_stage="Fruiting",
                location="Kolkata, West Bengal",
                language="English",
                symptoms="Brown circular spots with concentric rings are visible on older lower leaves.",
                disease="Early Blight",
                confidence=86,
                severity="Moderate",
                recommendation="Sample completed advisory.",
                prevention="Improve airflow and field sanitation.",
                status="Completed",
            ),
            AdvisoryCase(
                owner_username="farmer",
                farmer_name="Ramesh Farmer",
                crop="Rice",
                growth_stage="Tillering",
                location="Bardhaman, West Bengal",
                language="Bengali",
                symptoms="পাতায় বাদামি ডিম্বাকার দাগ এবং হলুদ বর্ডার দেখা যাচ্ছে।",
                disease="Brown Spot",
                confidence=80,
                severity="Moderate",
                recommendation="Sample escalated advisory.",
                prevention="Balanced nutrition and drainage.",
                status="Escalated",
                escalated=True,
            ),
        ]
        db.add_all(samples)
        db.commit()
