import re
from typing import Optional
from fastapi import Header, HTTPException

USERS = {
    "farmer": {"password": "farmer123", "role": "farmer", "name": "Ramesh Farmer"},
    "officer": {"password": "officer123", "role": "officer", "name": "Agriculture Officer"},
    "admin": {"password": "admin123", "role": "admin", "name": "System Admin"},
}

PHONE = re.compile(r"\b(?:\+?91[-\s]?)?[6-9]\d{9}\b")
EMAIL = re.compile(r"[\w.+-]+@[\w.-]+\.[A-Za-z]{2,}")

def mask_pii(text: str) -> str:
    return EMAIL.sub("[EMAIL]", PHONE.sub("[PHONE]", text or ""))

def role_context(
    x_app_role: Optional[str] = Header(default=None, alias="X-App-Role"),
    x_app_user: Optional[str] = Header(default=None, alias="X-App-User"),
    x_legacy_role: Optional[str] = Header(default=None, alias="X-Demo-Role"),
    x_legacy_user: Optional[str] = Header(default=None, alias="X-Demo-User"),
):
    role = (x_app_role or x_legacy_role or "farmer").lower()
    username = (x_app_user or x_legacy_user or "farmer").lower()
    return {"role": role, "username": username}

def require_role(context: dict, *allowed: str):
    if context["role"] not in allowed:
        raise HTTPException(status_code=403, detail="Your role cannot access the requested resource.")
