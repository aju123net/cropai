CROP_CATALOG = {
    "Rice": ["Seedling", "Tillering", "Panicle initiation", "Flowering", "Grain filling"],
    "Tomato": ["Seedling", "Vegetative", "Flowering", "Fruiting"],
    "Potato": ["Sprouting", "Vegetative", "Tuber initiation", "Tuber bulking"],
    "Wheat": ["Seedling", "Tillering", "Stem elongation", "Heading", "Grain filling"],
    "Mustard": ["Seedling", "Vegetative", "Flowering", "Pod formation"],
    "Chilli": ["Seedling", "Vegetative", "Flowering", "Fruiting"],
}

DISEASE_RULES = {
    "Rice": [
        {"disease":"Brown Spot","keywords":["brown spot","oval spot","yellow halo","brown lesion"],"base":68,"severity":"Moderate"},
        {"disease":"Rice Blast","keywords":["diamond lesion","spindle spot","neck rot","grey center"],"base":72,"severity":"High"},
        {"disease":"Bacterial Leaf Blight","keywords":["yellowing","wavy margin","leaf drying","wilting"],"base":66,"severity":"High"},
        {"disease":"Nitrogen Deficiency","keywords":["uniform yellow","older leaves yellow","pale green","slow growth"],"base":64,"severity":"Low"},
    ],
    "Tomato": [
        {"disease":"Early Blight","keywords":["brown spot","concentric ring","older leaves","target spot","yellow halo"],"base":72,"severity":"Moderate"},
        {"disease":"Late Blight","keywords":["water soaked","dark lesion","white growth","rapid spread"],"base":75,"severity":"High"},
        {"disease":"Tomato Leaf Curl","keywords":["leaf curl","curled leaves","stunted","whitefly"],"base":70,"severity":"Moderate"},
        {"disease":"Powdery Mildew","keywords":["white powder","powdery","white patches"],"base":67,"severity":"Moderate"},
    ],
    "Potato": [
        {"disease":"Late Blight","keywords":["dark lesion","water soaked","white growth","rapid spread"],"base":75,"severity":"High"},
        {"disease":"Early Blight","keywords":["target spot","concentric ring","older leaves","brown spot"],"base":71,"severity":"Moderate"},
        {"disease":"Aphid Attack","keywords":["aphid","sticky leaf","small insects","leaf curl"],"base":65,"severity":"Moderate"},
    ],
    "Wheat": [
        {"disease":"Wheat Rust","keywords":["orange pustule","rust","powder","yellow stripe"],"base":73,"severity":"High"},
        {"disease":"Powdery Mildew","keywords":["white powder","powdery patch"],"base":67,"severity":"Moderate"},
    ],
    "Mustard": [
        {"disease":"Alternaria Blight","keywords":["dark spot","concentric ring","leaf spot","pod spot"],"base":71,"severity":"Moderate"},
        {"disease":"Aphid Attack","keywords":["aphid","sticky","cluster insects","curl"],"base":67,"severity":"Moderate"},
    ],
    "Chilli": [
        {"disease":"Anthracnose","keywords":["sunken spot","fruit rot","dark circular","orange spores"],"base":72,"severity":"High"},
        {"disease":"Leaf Curl","keywords":["curl","whitefly","stunted","small leaves"],"base":69,"severity":"Moderate"},
    ],
}

SEED_KNOWLEDGE = [
    ("Tomato Early Blight Guide","Tomato","Early Blight","Remove heavily infected lower leaves. Avoid overhead irrigation, improve airflow, rotate crops, and use a locally approved bio-fungicide or copper-based product strictly according to its label and local agriculture guidance. Monitor new leaves every 48 to 72 hours."),
    ("Tomato Late Blight Guide","Tomato","Late Blight","Isolate affected plants, remove infected tissue safely, keep foliage dry, improve drainage, and contact an agriculture officer quickly because late blight can spread rapidly in cool humid weather."),
    ("Rice Brown Spot Guide","Rice","Brown Spot","Use clean seed, balanced nutrition, suitable potassium where soil testing supports it, and improved drainage. Remove heavily infected residue and avoid unnecessary nitrogen application."),
    ("Rice Blast Guide","Rice","Rice Blast","Avoid excess nitrogen, maintain recommended plant spacing and water management, remove infected residue, and consult local guidance for an approved fungicide schedule when disease is confirmed."),
    ("Rice Bacterial Leaf Blight Guide","Rice","Bacterial Leaf Blight","Avoid moving through wet fields, reduce excess nitrogen, improve drainage, use clean seed, and prefer resistant varieties in the next planting cycle."),
    ("Potato Blight Guide","Potato","Late Blight","Inspect the field daily, remove infected foliage carefully, avoid leaf wetness, improve airflow, and get local expert advice before applying any crop-protection product."),
    ("Potato Early Blight Guide","Potato","Early Blight","For potato early blight, inspect older foliage for target-like concentric lesions, remove heavily affected foliage safely, avoid prolonged leaf wetness, maintain balanced nutrition, rotate away from solanaceous crops, and verify any crop-protection treatment with local agricultural guidance."),
    ("Potato Tuber Health Guide","Potato","All","For harvested potato tubers showing brown lesions, sunken areas, discoloration, softening, dry rot, wet rot or mould, separate damaged tubers from healthy stock, keep the produce dry and well ventilated, avoid storing visibly rotting tubers, inspect for spread during storage, and consult an agriculture officer or plant-health laboratory for confirmation before treatment decisions."),
    ("Wheat Rust Guide","Wheat","Wheat Rust","Monitor nearby fields, remove volunteer plants, avoid late excessive nitrogen, and use a locally approved fungicide only after diagnosis is confirmed."),
    ("Mustard Alternaria Guide","Mustard","Alternaria Blight","Use healthy seed, remove infected debris, avoid overhead irrigation, maintain spacing, and follow local seed-treatment and crop-protection recommendations."),
    ("General Irrigation Safety","All","All","Water early in the day, avoid prolonged leaf wetness, prevent waterlogging, and adjust irrigation to crop stage, soil texture, rainfall, and drainage."),
    ("General Pesticide Safety","All","All","Do not use an unverified pesticide dose. Confirm the diagnosis, read the product label, wear protective equipment, observe pre-harvest intervals, and follow local agriculture department guidance."),
]
