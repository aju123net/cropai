from __future__ import annotations

import json
import shutil
import time
import uuid
from collections import defaultdict
from pathlib import Path

from fastapi import Depends, FastAPI, File, Form, HTTPException, UploadFile
from fastapi.middleware.cors import CORSMiddleware
from fastapi.staticfiles import StaticFiles
from sqlalchemy import func
from sqlalchemy.orm import Session

from .catalog import CROP_CATALOG, DISEASE_RULES
from .config import API_PREFIX, APP_NAME, AVAILABLE_MODELS, EMBEDDING_MODEL, FRONTEND_ORIGINS, MOCK_LLM, TEXT_MODEL, UPLOAD_DIR, VISION_MODEL, WHISPER_MODEL, KNOWLEDGE_UPLOAD_DIR
from .database import Base, SessionLocal, engine, get_db
from .models import AdvisoryCase, ChatMessage, Conversation, ExecutionLog, GuardrailEvent, KnowledgeChunk, KnowledgeDocument, ModelSetting, PromptSetting
from .schemas import AdvisoryCreate, ChatRequest, FeedbackRequest, KnowledgeTextCreate, LoginRequest, ModelUpdate, OfficerUpdate, PromptUpdate, SyntheticRequest, ToolCallRequest
from .security import USERS, mask_pii, require_role, role_context
from .seed import seed_database
from .services import analyze_case, as_dict, chat_with_case, create_synthetic_cases, delete_document_vectors, extract_soil_report, get_model_settings, get_prompts, get_soil_profile, get_weather, index_document, json_load, read_knowledge_file, rebuild_vector_index, retrieve_guidance, save_and_clean_image, validate_advisory_input, validate_crop_image_context, validate_multimodal_advisory_context

Base.metadata.create_all(bind=engine)
with SessionLocal() as seed_db: seed_database(seed_db)

app = FastAPI(title=f"{APP_NAME} API", version="2.0.0", description="AI-powered crop advisory and disease resolution platform")
app.add_middleware(CORSMiddleware, allow_origins=FRONTEND_ORIGINS, allow_credentials=True, allow_methods=["*"], allow_headers=["*"])
app.mount("/uploads", StaticFiles(directory=str(UPLOAD_DIR)), name="uploads")

def serialise_case(case: AdvisoryCase):
    data = as_dict(case)
    for field, fallback in [("image_observations",{}),("weather_context",{}),("soil_context",{}),("retrieved_sources",[]),("agent_trace",[])]: data[field] = json_load(getattr(case, field), fallback)
    return data

def get_case_or_404(db: Session, case_id: int):
    case = db.get(AdvisoryCase, case_id)
    if not case: raise HTTPException(404, "Advisory case not found.")
    return case

@app.get(f"{API_PREFIX}/health")
def health(db: Session = Depends(get_db)):
    return {"status":"ok","app":APP_NAME,"version":"2.0.0","model_service":"fallback" if MOCK_LLM else "live","database":"connected","knowledge_chunks":db.query(KnowledgeChunk).count()}

@app.post(f"{API_PREFIX}/login")
@app.post(f"{API_PREFIX}/demo-login", include_in_schema=False)
def login(payload: LoginRequest):
    user = USERS.get(payload.username.lower())
    if not user or user["password"] != payload.password: raise HTTPException(401, "Invalid username or password.")
    return {"username":payload.username.lower(),"role":user["role"],"name":user["name"]}

@app.get(f"{API_PREFIX}/catalog")
def catalog():
    return {"crops":[{"name":crop,"growth_stages":stages,"diseases":[r["disease"] for r in DISEASE_RULES.get(crop,[])]} for crop, stages in CROP_CATALOG.items()],"languages":["English","Hindi","Bengali"],"regions":["West Bengal","Odisha","Bihar","Jharkhand","Assam"],"soil_types":["Alluvial loam","Clay loam","Sandy loam","Laterite","Black soil"]}

@app.get(f"{API_PREFIX}/weather")
async def weather(location: str): return await get_weather(location)

@app.get(f"{API_PREFIX}/soil/{{location}}")
def soil(location: str, soil_type: str = ""): return get_soil_profile(location, soil_type)

@app.get(f"{API_PREFIX}/crops/{{crop}}/diseases")
def crop_diseases(crop: str): return DISEASE_RULES.get(crop, [])

@app.get(f"{API_PREFIX}/treatments")
def treatments(): return {"items":["Field sanitation","Irrigation correction","Sticky traps","Locally approved bio-control","Expert-confirmed crop protection"]}

@app.post(f"{API_PREFIX}/advisories")
async def create_advisory(payload: AdvisoryCreate, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"farmer","admin")
    validation = await validate_advisory_input(db, payload.model_dump(), context["role"])
    if not validation["allowed"]:
        raise HTTPException(
            status_code=422,
            detail={
                "code": "ADVISORY_INPUT_BLOCKED",
                "message": "Please correct the highlighted crop-advisory fields before analysis.",
                "field_errors": validation["field_errors"],
                "guardrail_mode": validation["mode"],
            },
        )

    case = AdvisoryCase(owner_username=context["username"], **validation["cleaned"])
    db.add(case); db.commit(); db.refresh(case)
    return {
        **serialise_case(case),
        "input_guardrail": {
            "status": "passed",
            "mode": validation["mode"],
            "model_used": validation["model_used"],
        },
    }

@app.get(f"{API_PREFIX}/advisories")
def list_advisories(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    query = db.query(AdvisoryCase)
    if context["role"] == "farmer": query = query.filter(AdvisoryCase.owner_username == context["username"])
    elif context["role"] == "officer": query = query.filter(AdvisoryCase.escalated == True)  # noqa: E712
    return [serialise_case(c) for c in query.order_by(AdvisoryCase.created_at.desc()).all()]

@app.get(f"{API_PREFIX}/advisories/{{case_id}}")
def get_advisory(case_id: int, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    case = get_case_or_404(db, case_id)
    if context["role"] == "farmer" and case.owner_username != context["username"]: raise HTTPException(403, "You can view only your advisory cases.")
    return serialise_case(case)

@app.post(f"{API_PREFIX}/advisories/{{case_id}}/image")
async def upload_image(
    case_id: int,
    image: UploadFile = File(...),
    context: dict = Depends(role_context),
    db: Session = Depends(get_db),
):
    require_role(context, "farmer", "admin")
    case = get_case_or_404(db, case_id)
    if context["role"] == "farmer" and case.owner_username != context["username"]:
        raise HTTPException(403, "You can upload images only to your advisory cases.")
    if not image.content_type or not image.content_type.startswith("image/"):
        raise HTTPException(400, "Please upload a crop image.")

    try:
        path, metadata = save_and_clean_image(
            await image.read(),
            image.filename or "crop.jpg",
            case_id,
        )
    except ValueError as exc:
        raise HTTPException(400, str(exc)) from exc

    disk_path = Path(UPLOAD_DIR) / "images" / Path(path).name
    validation = await validate_crop_image_context(
        db,
        str(disk_path),
        case.crop,
        context["role"],
        case.id,
    )

    if not validation["allowed"]:
        disk_path.unlink(missing_ok=True)
        if validation.get("validation_unavailable"):
            raise HTTPException(
                status_code=503,
                detail={
                    "code": "CROP_IMAGE_VALIDATION_UNAVAILABLE",
                    "message": validation["reason"],
                    "image_error": validation["reason"],
                    "detected_subject": validation["primary_subject"],
                    "detected_category": validation["category"],
                },
            )
        raise HTTPException(
            status_code=422,
            detail={
                "code": "CROP_IMAGE_REJECTED",
                "message": validation["reason"],
                "image_error": validation["reason"],
                "detected_subject": validation["primary_subject"],
                "detected_category": validation["category"],
                "confidence": validation["confidence"],
            },
        )

    # Reconcile the dropdown, actual image subject, and symptom description
    # before disease rules or RAG are allowed to use the case crop.
    context_resolution = validate_multimodal_advisory_context(
        db,
        case,
        validation,
        context["role"],
    )
    if not context_resolution["allowed"]:
        disk_path.unlink(missing_ok=True)
        raise HTTPException(
            status_code=422,
            detail={
                "code": "ADVISORY_CONTEXT_MISMATCH",
                "message": (
                    "The selected crop, uploaded image, and symptom description "
                    "do not refer to the same crop. Please correct the highlighted input."
                ),
                "field_errors": context_resolution["field_errors"],
                "image_error": context_resolution["field_errors"].get("image"),
                "context_resolution": context_resolution,
            },
        )

    case.image_path = path
    case.image_observations = json.dumps(
        {
            "file_metadata": metadata,
            "context_guardrail": validation,
            "context_resolution": context_resolution,
        },
        ensure_ascii=False,
    )
    db.add(case)
    db.commit()
    return {
        "image_path": path,
        "metadata": metadata,
        "context_guardrail": validation,
        "context_resolution": context_resolution,
    }


@app.delete(f"{API_PREFIX}/advisories/{{case_id}}/draft")
def delete_advisory_draft(
    case_id: int,
    context: dict = Depends(role_context),
    db: Session = Depends(get_db),
):
    """Remove an empty draft created before an image guardrail rejection."""
    require_role(context, "farmer", "admin")
    case = get_case_or_404(db, case_id)
    if context["role"] == "farmer" and case.owner_username != context["username"]:
        raise HTTPException(403, "You can delete only your advisory drafts.")
    if case.status != "Draft" or case.image_path or case.soil_report_path:
        raise HTTPException(409, "Only an empty Draft advisory can be removed.")
    db.delete(case)
    db.commit()
    return {"message": "Draft advisory removed."}

@app.post(f"{API_PREFIX}/advisories/{{case_id}}/soil-report")
async def upload_soil_report(case_id: int, report: UploadFile = File(...), context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"farmer","admin"); case = get_case_or_404(db,case_id)
    try: path, text = extract_soil_report(await report.read(), report.filename or "soil-report.pdf", case_id)
    except ValueError as exc: raise HTTPException(400,str(exc))
    case.soil_report_path = path; case.soil_report_text = text; db.add(case); db.commit()
    return {"soil_report_path":path,"extracted_text_preview":text[:500]}

@app.post(f"{API_PREFIX}/advisories/{{case_id}}/analyze")
async def run_analysis(case_id: int, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context, "farmer", "admin")
    case = get_case_or_404(db, case_id)

    # When no image was supplied, the create-stage guardrail has intentionally
    # validated agricultural relevance only. Reconcile dropdown and symptom crop
    # here so a text-only case cannot bypass crop consistency validation.
    stored_image_context = json_load(case.image_observations, {})
    existing_resolution = (
        stored_image_context.get("context_resolution")
        or stored_image_context.get("file_metadata", {}).get("context_resolution")
        or {}
    )
    if not existing_resolution:
        image_validation = (
            stored_image_context.get("context_guardrail")
            or stored_image_context.get("file_metadata", {}).get("context_guardrail")
            or {
                "allowed": True,
                "farming_context": True,
                "category": "unknown",
                "primary_subject": "",
                "detected_crop": "",
                "crop_match": "uncertain",
                "confidence": 0,
                "reason": "No image was supplied.",
                "model_used": "",
            }
        )
        context_resolution = validate_multimodal_advisory_context(
            db,
            case,
            image_validation,
            context["role"],
        )
        if not context_resolution["allowed"]:
            raise HTTPException(
                status_code=422,
                detail={
                    "code": "ADVISORY_CONTEXT_MISMATCH",
                    "message": (
                        "The selected crop and symptom description are inconsistent. "
                        "Please correct the highlighted input."
                    ),
                    "field_errors": context_resolution["field_errors"],
                    "context_resolution": context_resolution,
                },
            )

    try:
        return await analyze_case(db, case, context["role"])
    except HTTPException:
        raise
    except Exception as exc:
        db.add(
            ExecutionLog(
                case_id=case_id,
                user_role=context["role"],
                agent_name="Supervisor Agent",
                tool_name="analysis_pipeline",
                status="FAILED",
                message=str(exc)[:500],
            )
        )
        db.commit()
        raise HTTPException(
            500,
            {
                "code": "ANALYSIS_FAILED",
                "message": (
                    "The advisory could not be completed. "
                    "Please verify the image and try again."
                ),
            },
        )

@app.post(f"{API_PREFIX}/advisories/{{case_id}}/feedback")
def feedback(case_id: int, payload: FeedbackRequest, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    case = get_case_or_404(db,case_id); case.feedback_rating = payload.rating; case.feedback_comment = mask_pii(payload.comment); db.add(case); db.commit(); return {"message":"Feedback saved."}

@app.post(f"{API_PREFIX}/advisories/{{case_id}}/escalate")
def escalate(case_id: int, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"farmer","admin"); case = get_case_or_404(db,case_id); case.escalated = True; case.status = "Escalated"; db.add(case)
    db.add(ExecutionLog(case_id=case_id,user_role=context["role"],agent_name="Supervisor Agent",tool_name="create_officer_escalation",status="SUCCESS",message="Case sent to agriculture officer.")); db.commit(); return serialise_case(case)

@app.put(f"{API_PREFIX}/officer/cases/{{case_id}}")
def officer_review(case_id: int, payload: OfficerUpdate, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"officer","admin"); case = get_case_or_404(db,case_id); case.officer_note = mask_pii(payload.note); case.status = "Resolved" if payload.resolved else "Officer Reviewed"; db.add(case); db.commit(); return serialise_case(case)

@app.post(f"{API_PREFIX}/chat")
async def chat(payload: ChatRequest, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    case = get_case_or_404(db,payload.case_id)
    return await chat_with_case(db,case,mask_pii(payload.message),payload.language,payload.conversation_id)

@app.get(f"{API_PREFIX}/conversations")
def conversations(case_id: int | None = None, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    query = db.query(Conversation)
    if case_id: query = query.filter(Conversation.case_id == case_id)
    rows = query.order_by(Conversation.updated_at.desc()).all()
    return [as_dict(c) for c in rows]

@app.get(f"{API_PREFIX}/conversations/{{conversation_id}}")
def conversation_detail(conversation_id: int, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    conv = db.get(Conversation,conversation_id)
    if not conv: raise HTTPException(404,"Conversation not found.")
    return {**as_dict(conv),"messages":[as_dict(m) for m in db.query(ChatMessage).filter(ChatMessage.conversation_id==conversation_id).order_by(ChatMessage.id).all()]}

@app.post(f"{API_PREFIX}/knowledge/text")
def create_knowledge_text(payload: KnowledgeTextCreate, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); doc = KnowledgeDocument(**payload.model_dump(),filename="manual-entry"); db.add(doc); db.commit(); db.refresh(doc); index_document(db,doc); return as_dict(doc)

@app.post(f"{API_PREFIX}/knowledge/upload")
async def upload_knowledge(file: UploadFile = File(...), title: str = Form(""), crop: str = Form("All"), disease: str = Form("All"), language: str = Form("English"), region: str = Form("All"), context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); data = await file.read()
    try: content = read_knowledge_file(data,file.filename or "document.txt")
    except ValueError as exc: raise HTTPException(400,str(exc))
    if len(content.strip()) < 20: raise HTTPException(400,"The document does not contain enough extractable text.")
    safe_name = f"{uuid.uuid4().hex[:8]}_{Path(file.filename or 'document').name}"; (KNOWLEDGE_UPLOAD_DIR/safe_name).write_bytes(data)
    doc = KnowledgeDocument(title=title or Path(file.filename or "Knowledge Document").stem,filename=safe_name,crop=crop,disease=disease,language=language,region=region,content=mask_pii(content)); db.add(doc); db.commit(); db.refresh(doc); index_document(db,doc); return as_dict(doc)

@app.get(f"{API_PREFIX}/knowledge/documents")
def knowledge_documents(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    return [{**as_dict(d),"chunk_count":len(d.chunks),"content":""} for d in db.query(KnowledgeDocument).order_by(KnowledgeDocument.created_at.desc()).all()]

@app.delete(f"{API_PREFIX}/knowledge/documents/{{document_id}}")
def delete_knowledge(document_id: int, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context, "admin")
    doc = db.get(KnowledgeDocument, document_id)
    if not doc:
        raise HTTPException(404, "Knowledge document not found.")

    settings = get_model_settings(db)
    try:
        delete_document_vectors(document_id, settings["embedding_model"])
    except Exception as exc:
        # The SQLite record is still deleted; stale vectors are ignored because
        # retrieval verifies that the source document still exists.
        db.add(
            ExecutionLog(
                user_role=context["role"],
                agent_name="RAG Agent",
                tool_name="delete_embeddings",
                status="FAILED",
                model_used=settings["embedding_model"],
                message=f"Vector cleanup failed: {str(exc)[:500]}",
            )
        )

    db.delete(doc)
    db.commit()
    return {"message": "Document deleted."}

@app.post(f"{API_PREFIX}/knowledge/reindex")
def reindex(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context, "admin")
    try:
        result = rebuild_vector_index(db)
    except Exception as exc:
        raise HTTPException(502, f"Embedding reindex failed: {str(exc)[:700]}") from exc

    return {
        "message": "Knowledge embedding index rebuilt.",
        "documents": db.query(KnowledgeDocument).count(),
        "chunks": db.query(KnowledgeChunk).count(),
        **result,
    }

@app.get(f"{API_PREFIX}/admin/prompts")
def prompts(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); return get_prompts(db)

@app.put(f"{API_PREFIX}/admin/prompts")
def update_prompts(payload: PromptUpdate, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin")
    for key,value in payload.model_dump().items():
        row = db.query(PromptSetting).filter_by(key=key).first() or PromptSetting(key=key); row.value=value; db.add(row)
    db.commit(); return get_prompts(db)

@app.get(f"{API_PREFIX}/admin/model")
def model_config(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); return {**get_model_settings(db),"available_models":AVAILABLE_MODELS,"mode":"fallback" if MOCK_LLM else "live","env_defaults":{"text_model":TEXT_MODEL,"vision_model":VISION_MODEL,"embedding_model":EMBEDDING_MODEL,"whisper_model":WHISPER_MODEL}}

@app.put(f"{API_PREFIX}/admin/model")
def update_model(payload: ModelUpdate, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin")
    for key,value in payload.model_dump().items():
        row = db.query(ModelSetting).filter_by(key=key).first() or ModelSetting(key=key); row.value=str(value).lower() if isinstance(value,bool) else str(value); db.add(row)
    db.commit(); return {**get_model_settings(db),"available_models":AVAILABLE_MODELS,"mode":"fallback" if MOCK_LLM else "live"}

@app.get(f"{API_PREFIX}/admin/logs")
def logs(limit: int = 200, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); return [as_dict(x) for x in db.query(ExecutionLog).order_by(ExecutionLog.created_at.desc()).limit(min(limit,500)).all()]

@app.get(f"{API_PREFIX}/admin/guardrails")
def guardrails(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); return [as_dict(x) for x in db.query(GuardrailEvent).order_by(GuardrailEvent.created_at.desc()).limit(100).all()]

@app.get(f"{API_PREFIX}/admin/kpis")
def kpis(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin")
    cases = db.query(AdvisoryCase).all(); logs = db.query(ExecutionLog).all()
    def grouped(items, field):
        values=defaultdict(int)
        for item in items: values[getattr(item,field) or "Unknown"] += 1
        return [{"name":k,"value":v} for k,v in sorted(values.items(),key=lambda x:x[1],reverse=True)]
    durations=defaultdict(list)
    for log in logs: durations[log.agent_name or "Unknown"].append(log.duration_ms)
    feedback=[c.feedback_rating for c in cases if c.feedback_rating]
    return {"total_cases":len(cases),"images_analyzed":sum(bool(c.image_path) for c in cases),"resolved":sum(c.status=="Resolved" for c in cases),"escalated":sum(bool(c.escalated) for c in cases),"avg_confidence":round(sum(c.confidence for c in cases)/len(cases),1) if cases else 0,"avg_response_ms":round(sum(l.duration_ms for l in logs)/len(logs)) if logs else 0,"successful_tools":sum(l.status in {"SUCCESS","FALLBACK"} for l in logs),"failed_tools":sum(l.status=="FAILED" for l in logs),"feedback_score":round(sum(feedback)/len(feedback),1) if feedback else 0,"cases_by_crop":grouped(cases,"crop"),"common_diseases":grouped(cases,"disease"),"cases_by_location":grouped(cases,"location"),"cases_by_language":grouped(cases,"language"),"agent_execution_time":[{"name":k,"value":round(sum(v)/len(v))} for k,v in durations.items()],"status_distribution":grouped(cases,"status")}

@app.post(f"{API_PREFIX}/admin/synthetic/generate")
def synthetic(payload: SyntheticRequest, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin"); rows=create_synthetic_cases(db,payload.template,payload.count); return {"message":f"Generated {len(rows)} synthetic cases.","ids":[r.id for r in rows]}

MCP_TOOLS = [
    {"name":"get_weather","description":"Get current weather with resilient service fallback"},
    {"name":"get_soil_profile","description":"Get a synthetic soil profile and parse report pH"},
    {"name":"search_crop_guidance","description":"Search the agricultural knowledge base"},
    {"name":"create_officer_escalation","description":"Escalate an advisory case to an officer"},
]

@app.get(f"{API_PREFIX}/mcp/status")
def mcp_status(context: dict = Depends(role_context), db: Session = Depends(get_db)):
    last = db.query(ExecutionLog).filter(ExecutionLog.tool_name.in_([x["name"] for x in MCP_TOOLS])).order_by(ExecutionLog.created_at.desc()).first()
    return {"status":"online","server":"Integrated MCP Tool Gateway","transport":"FastAPI JSON tool calls","tools":MCP_TOOLS,"last_execution":as_dict(last) if last else None}

@app.post(f"{API_PREFIX}/mcp/tools/{{tool_name}}")
async def call_tool(tool_name: str, payload: ToolCallRequest, context: dict = Depends(role_context), db: Session = Depends(get_db)):
    require_role(context,"admin","officer"); start=time.perf_counter(); args=payload.arguments
    if tool_name=="get_weather": result=await get_weather(args.get("location","Kolkata"))
    elif tool_name=="get_soil_profile": result=get_soil_profile(args.get("location","Kolkata"),args.get("soil_type",""),args.get("report_text",""))
    elif tool_name=="search_crop_guidance": result=retrieve_guidance(db,args.get("query","crop guidance"),args.get("crop","All"),args.get("disease","All"),args.get("language","English"),args.get("region","All"),args.get("mode","basic"))
    elif tool_name=="create_officer_escalation":
        case=get_case_or_404(db,int(args.get("case_id",0))); case.escalated=True; case.status="Escalated"; db.add(case); db.commit(); result=serialise_case(case)
    else: raise HTTPException(404,"MCP tool not found.")
    duration=int((time.perf_counter()-start)*1000); db.add(ExecutionLog(user_role=context["role"],agent_name="MCP Tool Gateway",tool_name=tool_name,status="SUCCESS",duration_ms=duration,message="Manual MCP tool test")); db.commit()
    return {"tool":tool_name,"duration_ms":duration,"result":result}
