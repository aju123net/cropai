import os
os.environ["MOCK_LLM"] = "true"
from fastapi.testclient import TestClient
from app.main import app

client = TestClient(app)
HEADERS = {"X-Demo-Role":"farmer","X-Demo-User":"farmer"}

def test_health_and_login():
    assert client.get("/api/v1/health").status_code == 200
    login = client.post("/api/v1/demo-login",json={"username":"farmer","password":"farmer123"})
    assert login.status_code == 200 and login.json()["role"] == "farmer"

def test_end_to_end_advisory():
    case = client.post("/api/v1/advisories",headers=HEADERS,json={"farmer_name":"Demo","crop":"Tomato","growth_stage":"Fruiting","location":"Kolkata","language":"English","symptoms":"Brown circular spots with concentric rings on older lower leaves."})
    assert case.status_code == 200
    result = client.post(f"/api/v1/advisories/{case.json()['id']}/analyze",headers=HEADERS)
    assert result.status_code == 200
    assert result.json()["disease"] == "Early Blight"
    assert len(result.json()["agent_trace"]) >= 7
