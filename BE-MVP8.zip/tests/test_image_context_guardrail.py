from app.services import _normalise_image_context_guardrail_response


def test_tiger_is_blocked():
    result = _normalise_image_context_guardrail_response(
        {
            "allowed": True,
            "farming_context": False,
            "category": "animal",
            "primary_subject": "tiger",
            "confidence": 99,
            "reason": "A tiger is visible.",
        },
        "Potato",
    )
    assert result["allowed"] is False


def test_potato_is_accepted():
    result = _normalise_image_context_guardrail_response(
        {
            "allowed": True,
            "farming_context": True,
            "category": "tuber",
            "primary_subject": "potato tuber",
            "detected_crop": "Potato",
            "crop_match": "match",
            "plant_health_issue_visible": True,
            "health_observations": ["dark lesions"],
            "confidence": 94,
            "reason": "Potato crop-health image.",
        },
        "Potato",
    )
    assert result["allowed"] is True
