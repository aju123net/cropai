from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base
from app.models import AdvisoryCase
from app import services
from app.services import (
    _normalise_image_context_guardrail_response,
    validate_multimodal_advisory_context,
)


def make_db():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, expire_on_commit=False)()


def make_case(db, crop, symptoms, stage="Fruiting"):
    case = AdvisoryCase(
        owner_username="farmer",
        farmer_name="Farmer",
        crop=crop,
        growth_stage=stage,
        location="Kolkata",
        language="English",
        symptoms=symptoms,
        status="Draft",
    )
    db.add(case)
    db.commit()
    db.refresh(case)
    return case


def potato_image(confidence=95):
    return {
        "allowed": True,
        "farming_context": True,
        "category": "tuber",
        "primary_subject": "rotten potato tubers",
        "detected_crop": "Potato",
        "crop_match": "mismatch",
        "plant_health_issue_visible": True,
        "health_observations": ["brown rot lesions"],
        "confidence": confidence,
        "reason": "Agricultural potato image.",
        "model_used": "vision-model",
    }


def test_agricultural_crop_mismatch_is_deferred_to_multimodal_guardrail():
    result = _normalise_image_context_guardrail_response(
        {
            "accepted": True,
            "is_agricultural": True,
            "detected_category": "tuber",
            "detected_subject": "rotten potatoes",
            "detected_crop": "Potato",
            "crop_match": "mismatch",
            "confidence": 0.98,
            "reason": "Potato tubers with visible health symptoms.",
        },
        "Tomato",
    )
    assert result["allowed"] is True
    assert result["confidence"] == 98
    assert result["crop_match"] == "mismatch"


def test_image_and_explicit_symptoms_auto_correct_wrong_dropdown():
    db = make_db()
    case = make_case(db, "Tomato", "Rotten potato tubers with dark lesions.")
    result = validate_multimodal_advisory_context(db, case, potato_image())
    assert result["allowed"] is True
    assert result["auto_corrected"] is True
    assert result["resolved_crop"] == "Potato"
    assert case.crop == "Potato"
    assert case.growth_stage == "Vegetative"


def test_high_confidence_image_auto_corrects_generic_symptoms():
    db = make_db()
    case = make_case(db, "Tomato", "The crop is rotten with dark circular lesions.")
    result = validate_multimodal_advisory_context(db, case, potato_image())
    assert result["allowed"] is True
    assert result["auto_corrected"] is True
    assert result["resolved_crop"] == "Potato"


def test_conflicting_selected_crop_and_symptoms_block_wrong_image():
    db = make_db()
    case = make_case(db, "Tomato", "Rotten tomato fruits with dark lesions.")
    result = validate_multimodal_advisory_context(db, case, potato_image())
    assert result["allowed"] is False
    assert "image" in result["field_errors"]


def test_matching_potato_context_is_confirmed():
    db = make_db()
    case = make_case(db, "Potato", "The crop is rotten with dark lesions.", stage="Tuber bulking")
    result = validate_multimodal_advisory_context(db, case, potato_image())
    assert result["allowed"] is True
    assert result["auto_corrected"] is False
    assert result["resolved_crop"] == "Potato"


def test_live_input_guardrail_defers_crop_mismatch_until_image(monkeypatch):
    db = make_db()

    async def fake_call(messages, settings):
        return (
            {
                "allowed": False,
                "fields": {
                    "symptoms": {
                        "valid": False,
                        "reason": (
                            "Symptom 'potato rotten' is unrelated to the stated "
                            "crop 'Tomato'."
                        ),
                        "category": "crop_mismatch",
                    },
                    "previous_fertilizer": {
                        "valid": True,
                        "reason": "",
                        "category": "empty",
                    },
                    "previous_pesticide": {
                        "valid": True,
                        "reason": "",
                        "category": "empty",
                    },
                },
                "risk_flags": [],
                "summary": "Crop mismatch.",
            },
            "text-model",
            "live-primary-model",
            [],
        )

    monkeypatch.setattr(services, "MOCK_LLM", False)
    monkeypatch.setattr(services, "API_KEY", "test-key")
    monkeypatch.setattr(
        services,
        "_call_input_guardrail_with_failover",
        fake_call,
    )

    import asyncio

    result = asyncio.run(
        services.validate_advisory_input(
            db,
            {
                "farmer_name": "Farmer",
                "crop": "Tomato",
                "variety": "",
                "growth_stage": "Fruiting",
                "location": "Kolkata",
                "region": "West Bengal",
                "language": "English",
                "soil_type": "Alluvial loam",
                "previous_fertilizer": "",
                "previous_pesticide": "",
                "symptoms": "The potato is rotten with dark lesions.",
            },
        )
    )

    assert result["allowed"] is True
    assert result["field_errors"] == {}
