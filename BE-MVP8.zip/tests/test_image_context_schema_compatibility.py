from app.services import _normalise_image_context_guardrail_response


def test_revised_admin_schema_accepts_rotten_potato():
    result = _normalise_image_context_guardrail_response(
        {
            "accepted": True,
            "is_agricultural": True,
            "detected_subject": "potato tubers",
            "detected_category": "tuber",
            "crop_match": "match",
            "confidence": 0.98,
            "reason": (
                "The image shows potato tubers with visible health symptoms "
                "such as discoloration and lesions, making it suitable for "
                "agricultural analysis."
            ),
        },
        "Potato",
    )

    assert result["allowed"] is True
    assert result["farming_context"] is True
    assert result["category"] == "tuber"
    assert result["confidence"] == 98


def test_original_schema_accepts_rotten_potato():
    result = _normalise_image_context_guardrail_response(
        {
            "allowed": True,
            "farming_context": True,
            "category": "tuber",
            "primary_subject": "rotten potatoes",
            "detected_crop": "Potato",
            "crop_match": "match",
            "plant_health_issue_visible": True,
            "health_observations": ["brown lesions", "rot"],
            "confidence": 96,
            "reason": "Potato tubers show health issues.",
        },
        "Potato",
    )
    assert result["allowed"] is True


def test_tiger_is_always_blocked_even_if_model_says_accepted():
    result = _normalise_image_context_guardrail_response(
        {
            "accepted": True,
            "is_agricultural": True,
            "detected_subject": "tiger",
            "detected_category": "animal",
            "confidence": 0.99,
            "reason": "A tiger is visible.",
        },
        "Potato",
    )
    assert result["allowed"] is False
    assert result["farming_context"] is False
