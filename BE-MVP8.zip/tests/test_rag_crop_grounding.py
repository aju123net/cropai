from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base
from app.models import KnowledgeChunk, KnowledgeDocument
from app.services import _retrieve_with_tfidf


def make_db():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, expire_on_commit=False)()


def add_doc(db, title, crop, disease, content):
    doc = KnowledgeDocument(
        title=title,
        crop=crop,
        disease=disease,
        language="English",
        region="All",
        content=content,
        active=True,
    )
    db.add(doc)
    db.flush()
    db.add(KnowledgeChunk(document_id=doc.id, chunk_index=0, content=content))
    db.commit()


def test_metadata_rag_never_crosses_crop_boundary():
    db = make_db()
    add_doc(db, "Tomato Late Blight", "Tomato", "Late Blight", "Remove infected tomato leaves.")
    add_doc(db, "Potato Late Blight", "Potato", "Late Blight", "Inspect potato foliage and keep leaves dry.")
    add_doc(db, "General Safety", "All", "All", "Verify crop protection guidance locally.")

    rows = _retrieve_with_tfidf(
        db,
        "potato late blight dark water-soaked lesions",
        "Potato",
        "Late Blight",
        "metadata",
        4,
    )

    assert rows
    assert all(row["crop"] in {"Potato", "All"} for row in rows)
    assert not any(row["crop"] == "Tomato" for row in rows)


def test_metadata_rag_does_not_use_wrong_disease_for_same_crop():
    db = make_db()
    add_doc(db, "Tomato Early Blight", "Tomato", "Early Blight", "Concentric rings on older leaves.")
    add_doc(db, "Potato Late Blight", "Potato", "Late Blight", "Rapid water-soaked lesions.")
    add_doc(db, "General Safety", "All", "All", "Verify crop protection guidance locally.")

    rows = _retrieve_with_tfidf(
        db,
        "potato early blight concentric rings",
        "Potato",
        "Early Blight",
        "metadata",
        4,
    )

    assert rows
    assert all(row["crop"] == "All" for row in rows)
    assert not any(row["crop"] == "Tomato" for row in rows)
    assert not any(row["disease"] == "Late Blight" and row["crop"] == "Potato" for row in rows)
