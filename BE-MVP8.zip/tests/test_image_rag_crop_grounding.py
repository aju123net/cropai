
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.pool import StaticPool

from app.database import Base
from app.models import KnowledgeChunk, KnowledgeDocument
from app.services import (
    _ground_retrieved_sources,
    _retrieve_with_tfidf,
)


def make_db():
    engine = create_engine(
        "sqlite://",
        connect_args={"check_same_thread": False},
        poolclass=StaticPool,
    )
    Base.metadata.create_all(engine)
    return sessionmaker(bind=engine, expire_on_commit=False)()


def add_doc(db, title, crop, disease, content):
    document = KnowledgeDocument(
        title=title,
        crop=crop,
        disease=disease,
        language="English",
        region="All",
        content=content,
        active=True,
    )
    db.add(document)
    db.flush()
    chunk = KnowledgeChunk(
        document_id=document.id,
        chunk_index=0,
        content=content,
    )
    db.add(chunk)
    db.commit()
    return document, chunk


def test_final_source_guardrail_blocks_tomato_for_potato_case():
    db = make_db()
    tomato, _ = add_doc(
        db,
        "Tomato Early Blight Guide",
        "Tomato",
        "Early Blight",
        "Tomato leaf guidance.",
    )
    potato, _ = add_doc(
        db,
        "Potato Tuber Health Guide",
        "Potato",
        "All",
        "Potato tuber storage and rot guidance.",
    )

    raw_sources = [
        {
            "document_id": tomato.id,
            "chunk_index": 0,
            "title": "Tomato Early Blight Guide",
            "crop": "Tomato",
            "disease": "Early Blight",
            "content": "Tomato leaf guidance.",
        },
        {
            "document_id": potato.id,
            "chunk_index": 0,
            "title": "Potato Tuber Health Guide",
            "crop": "Potato",
            "disease": "All",
            "content": "Potato tuber storage and rot guidance.",
        },
    ]

    accepted, rejected = _ground_retrieved_sources(
        db,
        raw_sources,
        crop="Potato",
        disease="Early Blight",
        mode="metadata",
        top_k=4,
    )

    assert [row["title"] for row in accepted] == ["Potato Tuber Health Guide"]
    assert any(row["title"] == "Tomato Early Blight Guide" for row in rejected)


def test_image_terms_cannot_cross_crop_boundary():
    db = make_db()
    add_doc(
        db,
        "Tomato Early Blight Guide",
        "Tomato",
        "Early Blight",
        "Brown concentric spots on older tomato leaves.",
    )
    add_doc(
        db,
        "Potato Tuber Health Guide",
        "Potato",
        "All",
        "Separate damaged potato tubers and monitor rot during storage.",
    )
    add_doc(
        db,
        "General Safety",
        "All",
        "All",
        "Verify crop protection guidance locally.",
    )

    # Deliberately include highly tomato-like language in image observations.
    rows = _retrieve_with_tfidf(
        db,
        (
            "AUTHORITATIVE CROP: Potato. "
            "Image observations mention brown concentric spots and older leaves. "
            "Retrieve only Potato or general sources."
        ),
        crop="Potato",
        disease="Early Blight",
        mode="metadata",
        top_k=4,
    )

    assert rows
    assert all(row["crop"] in {"Potato", "All"} for row in rows)
    assert not any(row["crop"] == "Tomato" for row in rows)


def test_mislabelled_tomato_title_is_rejected_even_when_crop_tag_is_potato():
    db = make_db()
    wrong, _ = add_doc(
        db,
        "Tomato Disease Guide",
        "Potato",
        "All",
        "Incorrectly tagged content.",
    )

    accepted, rejected = _ground_retrieved_sources(
        db,
        [{
            "document_id": wrong.id,
            "chunk_index": 0,
            "title": wrong.title,
            "crop": "Potato",
            "disease": "All",
            "content": wrong.content,
        }],
        crop="Potato",
        disease="Early Blight",
        mode="metadata",
        top_k=4,
    )

    assert accepted == []
    assert rejected
