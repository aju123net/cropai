import { useEffect, useState } from 'react';
import { Check, Clipboard, MessageCircle, ShieldAlert, Speaker, Star } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { Link, useParams } from 'react-router-dom';
import api, { BACKEND_URL } from '../api/client';
import { Alert, Loading, PageHeader, StatusBadge } from '../components/Common';

export default function AdvisoryResult() {
  const { id } = useParams();
  const [data, setData] = useState(null);
  const [loading, setLoading] = useState(true);
  const [loadError, setLoadError] = useState('');
  const [message, setMessage] = useState('');
  const [rating, setRating] = useState(0);
  const [comment, setComment] = useState('');

  useEffect(() => {
    let active = true;

    async function fetchAdvisory() {
      setLoading(true);
      setLoadError('');

      try {
        const response = await api.get(`/advisories/${id}`);
        if (active) {
          setData(response.data);
        }
      } catch (error) {
        if (active) {
          setLoadError(error.message || 'Unable to load the advisory case.');
        }
      } finally {
        if (active) {
          setLoading(false);
        }
      }
    }

    void fetchAdvisory();

    return () => {
      active = false;
    };
  }, [id]);

  if (loading) {
    return <Loading text="Loading advisory result..." />;
  }

  if (loadError || !data) {
    return (
      <>
        <PageHeader
          title={`Advisory Case #${id}`}
          description="The advisory details could not be loaded."
        />
        <Alert type="error">{loadError || 'Advisory case was not found.'}</Alert>
        <Link className="btn secondary" to="/history">Back to advisory history</Link>
      </>
    );
  }

  const advisoryMarkdown = normalizeMarkdown(data.recommendation);

  const speak = () => {
    if (!('speechSynthesis' in window)) {
      setMessage('Voice playback is not supported in this browser.');
      return;
    }

    window.speechSynthesis.cancel();
    const recommendation = stripMarkdown(advisoryMarkdown);
    const utterance = new SpeechSynthesisUtterance(`${data.disease || ''}. ${recommendation}`);
    utterance.lang = data.language === 'Bengali'
      ? 'bn-IN'
      : data.language === 'Hindi'
        ? 'hi-IN'
        : 'en-IN';
    window.speechSynthesis.speak(utterance);
  };

  const copy = async () => {
    try {
      await navigator.clipboard.writeText(advisoryMarkdown);
      setMessage('Recommendation copied.');
    } catch {
      setMessage('The browser could not copy the recommendation.');
    }
  };

  const escalate = async () => {
    try {
      const response = await api.post(`/advisories/${id}/escalate`);
      setData(response.data);
      setMessage('Case escalated to an agriculture officer.');
    } catch (error) {
      setMessage(error.message || 'Unable to escalate the case.');
    }
  };

  const feedback = async () => {
    try {
      await api.post(`/advisories/${id}/feedback`, { rating, comment });
      setMessage('Thank you. Feedback saved.');
    } catch (error) {
      setMessage(error.message || 'Unable to save feedback.');
    }
  };

  return (
    <>
      <PageHeader
        title={`Advisory Case #${id}`}
        description={`${data.crop} • ${data.growth_stage} • ${data.location}`}
      >
        <Link className="btn secondary" to={`/chat?case=${id}`}>
          <MessageCircle size={16} />
          Ask follow-up
        </Link>
      </PageHeader>

      {message && (
        <Alert type="success" onClose={() => setMessage('')}>
          {message}
        </Alert>
      )}

      <div className="result-grid">
        <section>
          <div className="card diagnosis-card">
            <div>
              <small>Possible condition</small>
              <h1>{data.disease || 'Analysis pending'}</h1>
              <p>{data.crop} at {data.growth_stage} stage</p>
            </div>
            <div className="score">
              <small>Severity</small>
              <StatusBadge value={data.severity} />
              <b>{Number(data.confidence || 0)}%</b>
              <small>confidence</small>
            </div>
          </div>

          {data.image_path && (
            <img
              className="crop-image"
              src={`${BACKEND_URL}${data.image_path}`}
              alt="Uploaded crop"
            />
          )}

          <div className="card markdown-card">
            <div className="card-toolbar">
              <h3>AI advisory</h3>
              <div>
                <button type="button" onClick={copy}>
                  <Clipboard size={16} />
                  Copy
                </button>
                <button type="button" onClick={speak}>
                  <Speaker size={16} />
                  Listen
                </button>
              </div>
            </div>

            <ReactMarkdown>
              {advisoryMarkdown}
            </ReactMarkdown>

            <div className="prevention">
              <ShieldAlert size={20} />
              <div>
                <b>Prevention</b>
                <p>{data.prevention || 'Follow local agricultural guidance and monitor the crop.'}</p>
              </div>
            </div>
          </div>

          <div className="card feedback">
            <h3>Was this advisory useful?</h3>
            <div className="stars">
              {[1, 2, 3, 4, 5].map((value) => (
                <button
                  type="button"
                  aria-label={`Rate ${value} out of 5`}
                  className={rating >= value ? 'active' : ''}
                  onClick={() => setRating(value)}
                  key={value}
                >
                  <Star size={22} />
                </button>
              ))}
            </div>
            <textarea
              value={comment}
              onChange={(event) => setComment(event.target.value)}
              placeholder="Optional feedback"
            />
            <button
              type="button"
              className="btn secondary"
              disabled={!rating}
              onClick={feedback}
            >
              Submit feedback
            </button>
          </div>
        </section>

        <aside className="result-side">
          <div className="card">
            <h3>Context used</h3>
            {data.image_observations?.detected_crop && (
              <div className="detected-crop-badge">
                <b>Detected crop:</b> {data.image_observations.detected_crop}
              </div>
            )}
            <Context title="Image observations" value={data.image_observations} />
            <Context title="Weather" value={data.weather_context} />
            <Context title="Soil" value={data.soil_context} />
          </div>

          <div className="card">
            <h3>Retrieved sources</h3>
            {data.retrieved_sources?.length ? (
              data.retrieved_sources.map((source, index) => (
                <div className="source" key={`${source.title || 'source'}-${index}`}>
                  <b>{source.title || 'Agricultural guidance'}</b>
                  <small>
                    {source.crop || 'All crops'} • {source.disease || 'General'}
                    {source.crop && source.crop.toLowerCase() !== (data.crop || '').toLowerCase() && (
                      <span className="source-mismatch"> (different crop)</span>
                    )}
                    {source.score != null && ` • score ${source.score}`}
                  </small>
                </div>
              ))
            ) : (
              <p className="muted">No knowledge sources were returned.</p>
            )}
          </div>

          <div className="card">
            <h3>Agent execution trace</h3>
            <div className="trace">
              {data.agent_trace?.length ? (
                data.agent_trace.map((trace, index) => (
                  <div key={`${trace.agent || 'agent'}-${index}`}>
                    <span><Check size={14} /></span>
                    <div>
                      <b>{trace.agent || 'Agent'}</b>
                      <small>{trace.tool || 'internal'} • {trace.duration_ms ?? 0} ms</small>
                      <p>{trace.message || 'Completed'}</p>
                    </div>
                  </div>
                ))
              ) : (
                <p className="muted">No execution trace is available.</p>
              )}
            </div>
          </div>

          {!data.escalated ? (
            <button type="button" className="btn danger block" onClick={escalate}>
              <ShieldAlert size={17} />
              Escalate to agriculture officer
            </button>
          ) : (
            <Alert type="warning">This case is in the officer queue.</Alert>
          )}
        </aside>
      </div>
    </>
  );
}

function Context({ title, value }) {
  return (
    <details>
      <summary>{title}</summary>
      <pre>{JSON.stringify(value ?? {}, null, 2)}</pre>
    </details>
  );
}


function normalizeMarkdown(value) {
  let text = extractRecommendationText(value).replace(/\r\n?/g, '\n').trim();
  if (!text) return 'Analysis is not completed.';

  // Model gateways sometimes return a JSON-encoded string or object.
  if (/^[\[{\"]/.test(text)) {
    try {
      const parsed = JSON.parse(text);
      const extracted = extractRecommendationText(parsed);
      if (extracted) text = extracted;
    } catch {
      // Keep the original text when it is ordinary Markdown, not JSON.
    }
  }

  // Convert literal escape sequences returned by some gateways into real lines.
  text = text
    .replace(/\\r\\n/g, '\n')
    .replace(/\\n/g, '\n')
    .replace(/\\t/g, '  ')
    .replace(/\u00a0/g, ' ')
    .replace(/[\u200B-\u200D\uFEFF]/g, '');

  // Remove an outer Markdown/text code fence. A fenced response would otherwise
  // display headings and bold markers as raw characters.
  text = text
    .replace(/^\s*```(?:markdown|md|text)?\s*\n?/i, '')
    .replace(/\n?\s*```\s*$/i, '')
    .trim();

  const lines = text.split('\n');
  const nonEmpty = lines.filter((line) => line.trim());

  if (nonEmpty.length) {
    const indentOf = (line) => (line.match(/^[ \t]*/) || [''])[0].replace(/\t/g, '    ').length;
    const minimumIndent = Math.min(...nonEmpty.map(indentOf));

    if (minimumIndent > 0) {
      text = lines.map((line) => removeIndent(line, minimumIndent)).join('\n');
    } else {
      // Some providers leave the first line unindented but indent the remainder
      // as a code block. Remove that accidental indentation when it dominates.
      const indentedCount = nonEmpty.filter((line) => indentOf(line) >= 4).length;
      if (indentedCount / nonEmpty.length >= 0.5) {
        text = lines.map((line) => indentOf(line) >= 4 ? removeIndent(line, 4) : line).join('\n');
      }
    }
  }

  // Common model variation: "###Heading" instead of "### Heading".
  return text
    .split('\n')
    .map((line) => line.replace(/^(#{1,6})([^#\s])/, '$1 $2'))
    .join('\n')
    .trim();
}

function extractRecommendationText(value) {
  if (value == null) return '';
  if (typeof value === 'string') return value;
  if (Array.isArray(value)) return value.map(extractRecommendationText).filter(Boolean).join('\n\n');
  if (typeof value === 'object') {
    return extractRecommendationText(
      value.recommendation
      ?? value.answer
      ?? value.content
      ?? value.text
      ?? value.message
      ?? '',
    );
  }
  return String(value);
}

function removeIndent(line, count) {
  let remaining = count;
  let index = 0;
  while (index < line.length && remaining > 0) {
    if (line[index] === '\t') remaining -= 4;
    else if (line[index] === ' ') remaining -= 1;
    else break;
    index += 1;
  }
  return line.slice(index);
}

function stripMarkdown(value) {
  return String(value || '')
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .replace(/[>*_`~]/g, '')
    .replace(/\n{2,}/g, '. ')
    .replace(/\n/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}
