import { useEffect, useRef, useState } from 'react';
import { Camera, LoaderCircle, Mic, Send, ShieldAlert, Speaker, Square } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useNavigate } from 'react-router-dom';
import api, { BACKEND_URL } from '../api/client';
import { Alert, PageHeader } from '../components/Common';

const STEPS = { WELCOME: 0, SYMPTOMS: 1, LANGUAGE: 2, ANALYZING: 3, RESULT: 4 };

export default function NewAdvisory() {
  const [step, setStep] = useState(STEPS.WELCOME);
  const [messages, setMessages] = useState([]);
  const [image, setImage] = useState(null);
  const [imagePreview, setImagePreview] = useState(null);
  const [symptoms, setSymptoms] = useState('');
  const [language, setLanguage] = useState('English');
  const [result, setResult] = useState(null);
  const [error, setError] = useState('');
  const [listening, setListening] = useState(false);
  const endRef = useRef(null);
  const recognition = useRef(null);
  const fileInputRef = useRef(null);

  const addBot = (content) => setMessages((p) => [...p, { role: 'bot', content, id: Date.now() }]);
  const addUser = (content) => setMessages((p) => [...p, { role: 'user', content, id: Date.now() }]);

  useEffect(() => {
    addBot("Hello! I'm KrishiSaarthi AI. Please upload a photo of your crop to get started.");
  }, []);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, step]);

  const handleImageFile = (file) => {
    if (!file) return;
    setImage(file);
    setImagePreview(URL.createObjectURL(file));
    setError('');
  };

  const sendImage = () => {
    if (!image) return;
    addUser('Photo uploaded');
    setStep(STEPS.SYMPTOMS);
    addBot('Photo received! What do you notice about your crop? You can describe symptoms or tap Skip.');
  };

  const skipSymptoms = () => {
    addUser('Skipped');
    setStep(STEPS.LANGUAGE);
    addBot('What language do you prefer for the advisory?');
  };

  const sendSymptoms = () => {
    const text = symptoms.trim();
    if (!text) return;
    addUser(text);
    setSymptoms('');
    setStep(STEPS.LANGUAGE);
    addBot('What language do you prefer for the advisory?');
  };

  const pickLanguage = async (lang) => {
    setLanguage(lang);
    addUser(lang);
    setStep(STEPS.ANALYZING);
    addBot('Analyzing your crop image...');

    try {
      const { data: created } = await api.post('/advisories', {
        farmer_name: 'Farmer',
        crop: '',
        growth_stage: '',
        location: 'Kolkata, West Bengal',
        language: lang,
        symptoms: '',
        has_image: true,
      });

      const fd = new FormData();
      fd.append('image', image);
      await api.post(`/advisories/${created.id}/image`, fd);

      const { data: analysis } = await api.post(`/advisories/${created.id}/analyze`);
      setResult(analysis);
      setStep(STEPS.RESULT);
    } catch (err) {
      setError(err.message || 'Something went wrong.');
      setStep(STEPS.WELCOME);
      addBot('Sorry, something went wrong. Please try again.');
    }
  };

  const speak = (text) => {
    if (!('speechSynthesis' in window)) return;
    window.speechSynthesis.cancel();
    const clean = String(text || '').replace(/```[\s\S]*?```/g, ' ').replace(/^#{1,6}\s+/gm, '').replace(/[>*_`~]/g, '').replace(/\n+/g, ' ').trim();
    const u = new SpeechSynthesisUtterance(clean);
    u.lang = language === 'Bengali' ? 'bn-IN' : language === 'Hindi' ? 'hi-IN' : 'en-IN';
    window.speechSynthesis.speak(u);
  };

  const voice = () => {
    const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SR) { setError('Use Chrome or Edge for voice input.'); return; }
    if (listening) { recognition.current?.stop(); return; }
    const r = new SR();
    r.lang = language === 'Bengali' ? 'bn-IN' : language === 'Hindi' ? 'hi-IN' : 'en-IN';
    r.interimResults = false;
    r.onresult = (e) => setSymptoms((p) => `${p} ${e.results[0][0].transcript}`.trim());
    r.onend = () => setListening(false);
    r.onerror = () => setListening(false);
    recognition.current = r;
    r.start();
    setListening(true);
  };

  const escalate = async () => {
    if (!result) return;
    try {
      await api.post(`/advisories/${result.id}/escalate`);
      setResult((p) => ({ ...p, escalated: true }));
      addBot('Case escalated to an agriculture officer.');
    } catch { setError('Unable to escalate.'); }
  };

  const startOver = () => {
    setStep(STEPS.WELCOME);
    setMessages([]);
    setImage(null);
    setImagePreview(null);
    setSymptoms('');
    setResult(null);
    setError('');
    setTimeout(() => addBot("Hello! I'm KrishiSaarthi AI. Please upload a photo of your crop to get started."), 100);
  };

  return (
    <>
      <PageHeader title="Crop Health Check" description="Upload a photo and get AI-powered crop guidance." />
      {error && <Alert type="error" onClose={() => setError('')}>{error}</Alert>}

      <div className="cw">
        <div className="cw-messages">
          {messages.map((m) => (
            <div key={m.id} className={`bubble-row ${m.role === 'bot' ? 'assistant' : 'user'}`}>
              <div className="bubble">
                {m.role === 'bot' ? (
                  <div className="chat-markdown"><ReactMarkdown>{m.content}</ReactMarkdown></div>
                ) : (
                  <p>{m.content}</p>
                )}
              </div>
            </div>
          ))}

          {step === STEPS.RESULT && result && (
            <div className="bubble-row assistant">
              <div className="bubble cw-result">
                {result.image_path && (
                  <img className="cw-img" src={`${BACKEND_URL}${result.image_path}`} alt="Crop" />
                )}
                <div className="cw-dx">
                  <small>Possible condition</small>
                  <h2>{result.disease || 'Analysis pending'}</h2>
                  <p>{result.crop} at {result.growth_stage} stage</p>
                  <div className="cw-score">
                    <span className={`badge ${(result.severity || '').toLowerCase()}`}>Severity: {result.severity}</span>
                    <b>{Number(result.confidence || 0)}%</b><small>confidence</small>
                  </div>
                </div>
                <div className="cw-md"><ReactMarkdown>{normMd(result.recommendation)}</ReactMarkdown></div>
                {result.prevention && (
                  <div className="cw-prev">
                    <ShieldAlert size={18} />
                    <div><b>Prevention</b><p>{result.prevention}</p></div>
                  </div>
                )}

                <details className="cw-ctx">
                  <summary>Image observations</summary>
                  <pre>{JSON.stringify(result.image_observations ?? {}, null, 2)}</pre>
                </details>
                <details className="cw-ctx">
                  <summary>Weather</summary>
                  <pre>{JSON.stringify(result.weather_context ?? {}, null, 2)}</pre>
                </details>
                <details className="cw-ctx">
                  <summary>Soil</summary>
                  <pre>{JSON.stringify(result.soil_context ?? {}, null, 2)}</pre>
                </details>
                {result.retrieved_sources?.length > 0 && (
                  <details className="cw-ctx">
                    <summary>Retrieved sources ({result.retrieved_sources.length})</summary>
                    <div className="cw-sources">
                      {result.retrieved_sources.map((s, i) => (
                        <div key={i} className="cw-src">
                          <b>{s.title || 'Agricultural guidance'}</b>
                          <small>{s.crop || 'All'} — {s.disease || 'General'}</small>
                        </div>
                      ))}
                    </div>
                  </details>
                )}
                {result.agent_trace?.length > 0 && (
                  <details className="cw-ctx">
                    <summary>Agent trace ({result.agent_trace.length} steps)</summary>
                    <div className="cw-trace">
                      {result.agent_trace.map((t, i) => (
                        <div key={i} className="cw-trace-item">
                          <b>{t.agent}</b>
                          <small>{t.tool} — {t.duration_ms ?? 0} ms — {t.status}</small>
                        </div>
                      ))}
                    </div>
                  </details>
                )}
                <div className="cw-btns">
                  <button type="button" className="btn secondary" onClick={() => speak(result.recommendation)}><Speaker size={15} /> Listen</button>
                  {!result.escalated ? (
                    <button type="button" className="btn secondary" onClick={escalate}><ShieldAlert size={15} /> Escalate</button>
                  ) : <span className="badge escalated">Escalated</span>}
                  <button type="button" className="btn primary" onClick={startOver}><Camera size={15} /> New advisory</button>
                </div>
              </div>
            </div>
          )}

          {step === STEPS.ANALYZING && (
            <div className="bubble-row assistant">
              <div className="bubble typing">Analyzing<span /><span /><span /></div>
            </div>
          )}
          <div ref={endRef} />
        </div>

        <div className="cw-input">
          {step === STEPS.WELCOME && (
            <div className="cw-upload">
              {!imagePreview ? (
                <div
                  className="cw-drop"
                  onClick={() => fileInputRef.current?.click()}
                  onDragOver={(e) => { e.preventDefault(); e.stopPropagation(); }}
                  onDrop={(e) => { e.preventDefault(); e.stopPropagation(); const f = e.dataTransfer.files?.[0]; if (f?.type.startsWith('image/')) handleImageFile(f); }}
                >
                  <Camera size={30} strokeWidth={1.5} />
                  <span>Tap to take or choose a photo</span>
                  <small>Clear, close-up photos give the best results</small>
                  <input ref={fileInputRef} type="file" accept="image/*" capture="environment" onChange={(e) => handleImageFile(e.target.files?.[0])} style={{ display: 'none' }} />
                </div>
              ) : (
                <div className="cw-preview">
                  <img src={imagePreview} alt="Preview" />
                  <button type="button" className="btn primary" onClick={sendImage}><Send size={16} /> Send</button>
                  <button type="button" className="btn secondary" onClick={() => { setImage(null); setImagePreview(null); }}>Remove</button>
                </div>
              )}
            </div>
          )}

          {step === STEPS.SYMPTOMS && (
            <div className="cw-row">
              <button type="button" className="cw-mic" onClick={voice}>{listening ? <Square size={18} /> : <Mic size={18} />}</button>
              <input className="cw-txt" value={symptoms} onChange={(e) => setSymptoms(e.target.value)} onKeyDown={(e) => e.key === 'Enter' && sendSymptoms()} placeholder="Describe symptoms or leave blank..." autoFocus />
              <button type="button" className="btn secondary" onClick={skipSymptoms}>Skip</button>
              <button type="button" className="btn primary" onClick={sendSymptoms} disabled={!symptoms.trim()}><Send size={16} /></button>
            </div>
          )}

          {step === STEPS.LANGUAGE && (
            <div className="cw-lang">
              {['English', 'Hindi', 'Bengali'].map((l) => (
                <button key={l} type="button" className="btn secondary" onClick={() => pickLanguage(l)}>{l}</button>
              ))}
            </div>
          )}

          {(step === STEPS.ANALYZING || step === STEPS.RESULT) && (
            <div className="cw-disabled">
              {step === STEPS.ANALYZING ? 'Analyzing your crop...' : 'Analysis complete. See result above.'}
            </div>
          )}
        </div>
      </div>
    </>
  );
}

function normMd(v) {
  let t = String(v || '').replace(/\r\n?/g, '\n').trim();
  if (!t) return 'Analysis is not completed.';
  t = t.replace(/\\n/g, '\n').replace(/^\s*```(?:markdown|md|text)?\s*\n?/i, '').replace(/\n?\s*```\s*$/i, '').trim();
  return t.split('\n').map((l) => l.replace(/^(#{1,6})([^#\s])/, '$1 $2')).join('\n').trim();
}
