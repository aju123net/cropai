@echo off
.venv\Scripts\activate.bat
python seed.py
uvicorn app.main:app --reload --host 0.0.0.0 --port 8000
