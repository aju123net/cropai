import { useState } from 'react';
import { NavLink, Outlet, useLocation } from 'react-router-dom';
import { Activity, BarChart3, BookOpen, Bot, ChevronRight, ClipboardList, FileClock, FlaskConical, History, LayoutDashboard, Leaf, LogOut, Menu, MessageCircle, PlusCircle, Settings2, ShieldCheck, SlidersHorizontal, Sprout, UserRoundCheck, X } from 'lucide-react';
import { useAuth } from '../context/AuthContext';

const farmer = [
  ['/','Dashboard',LayoutDashboard],['/new-advisory','New Crop Advisory',PlusCircle],['/history','Advisory History',History],['/chat','Follow-up Chat',MessageCircle]
];
const officer = [['/officer','Escalated Cases',UserRoundCheck]];
const admin = [
  ['/admin','KPI Dashboard',BarChart3],['/admin/prompts','Prompt Configuration',SlidersHorizontal],['/admin/knowledge','Knowledge Base',BookOpen],['/admin/synthetic','Synthetic Data',FlaskConical],['/admin/models','Model Configuration',Settings2],['/admin/agents','Agent & MCP Status',Bot],['/admin/logs','Logs & Guardrails',FileClock]
];
const titles = {'/':'Farmer Dashboard','/new-advisory':'New Crop Advisory','/history':'Advisory History','/chat':'Conversational Advisory','/officer':'Officer Case Queue','/admin':'Admin KPI Dashboard','/admin/prompts':'Prompt Configuration','/admin/knowledge':'Knowledge Base','/admin/synthetic':'Synthetic Data Generator','/admin/models':'Model Configuration','/admin/agents':'Agent & MCP Status','/admin/logs':'Logs & Guardrails'};
export default function Layout(){
  const {user,logout}=useAuth(); const [open,setOpen]=useState(false); const location=useLocation();
  const links=user.role==='admin'?admin:user.role==='officer'?officer:farmer;
  return <div className="app-shell">
    <aside className={open?'open':''}>
      <div className="brand"><span><Leaf size={20}/></span><div><b>KrishiSaarthi AI</b><small>BRAINSTORMERS LAB</small></div><button className="mobile-close" onClick={()=>setOpen(false)}><X/></button></div>
      <div className="nav-label">{user.role==='admin'?'Administration':user.role==='officer'?'Officer Workspace':'Farmer Workspace'}</div>
      <nav>{links.map(([path,label,Icon])=><NavLink key={path} to={path} end={path==='/'} onClick={()=>setOpen(false)}><Icon size={17}/><span>{label}</span><ChevronRight className="chev" size={14}/></NavLink>)}</nav>
      <div className="sidebar-footer"><div className="avatar">{user.name.split(' ').map(x=>x[0]).slice(0,2).join('')}</div><div className="who"><b>{user.name}</b><small>{user.role}</small></div><button onClick={logout} title="Logout"><LogOut size={17}/></button></div>
    </aside>
    <header><button className="menu-btn" onClick={()=>setOpen(true)}><Menu/></button><div><b>{titles[location.pathname]||'KrishiSaarthi AI'}</b><small>AI-powered crop advisory and disease resolution</small></div><span className="online"><i/> System Online</span></header>
    <main><Outlet/></main>
  </div>;
}
