import { AlertCircle, CheckCircle2, LoaderCircle, X } from 'lucide-react';

export function PageHeader({ title, description, children }) {
  return <div className="page-head"><div><h1>{title}</h1><p>{description}</p></div><div className="head-actions">{children}</div></div>;
}
export function Loading({ text='Loading...' }) { return <div className="loading"><LoaderCircle className="spin" size={22}/>{text}</div>; }
export function Empty({ title='Nothing here yet', text='New records will appear here.' }) { return <div className="empty"><AlertCircle size={34}/><h3>{title}</h3><p>{text}</p></div>; }
export function Alert({ type='info', children, onClose }) { return <div className={`alert ${type}`}>{type==='success'?<CheckCircle2 size={18}/>:<AlertCircle size={18}/>}<span>{children}</span>{onClose&&<button onClick={onClose}><X size={16}/></button>}</div>; }
export function StatusBadge({ value }) { const key=(value||'unknown').toLowerCase().replaceAll(' ','-'); return <span className={`badge ${key}`}>{value||'Unknown'}</span>; }
export function Field({ label, hint, error, children, className='' }) { return <div className={`field ${error?'invalid':''} ${className}`}><label>{label}</label>{children}{error?<small className="field-error">{error}</small>:hint&&<small>{hint}</small>}</div>; }
export function Modal({ title, children, onClose, footer }) { return <div className="modal-wrap" onMouseDown={e=>e.target===e.currentTarget&&onClose()}><div className="modal"><header><h3>{title}</h3><button onClick={onClose}><X size={19}/></button></header><div className="modal-body">{children}</div>{footer&&<footer>{footer}</footer>}</div></div>; }
const INDIA_TIME_ZONE = 'Asia/Kolkata';

export function parseApiDate(value) {
  if (!value) return null;
  let normalized = String(value).trim();
  // SQLite values are stored in UTC. Older API responses may not include a
  // timezone suffix, so explicitly interpret those values as UTC.
  if (/^\d{4}-\d{2}-\d{2}T/.test(normalized) && !/(Z|[+-]\d{2}:?\d{2})$/i.test(normalized)) {
    normalized += 'Z';
  }
  const date = new Date(normalized);
  return Number.isNaN(date.getTime()) ? null : date;
}

function formatIndiaDate(value, options, fallback='—') {
  const date = parseApiDate(value);
  if (!date) return fallback;
  return `${new Intl.DateTimeFormat('en-IN', {
    timeZone: INDIA_TIME_ZONE,
    ...options,
  }).format(date)} IST`;
}

export const fmtDate = value => formatIndiaDate(value, {
  day: '2-digit', month: 'short', year: 'numeric',
  hour: '2-digit', minute: '2-digit', hour12: true,
});

export const fmtDateCompact = value => formatIndiaDate(value, {
  day: '2-digit', month: 'short',
  hour: '2-digit', minute: '2-digit', hour12: true,
}, '');

export const fmtDateOnly = value => {
  const date = parseApiDate(value);
  if (!date) return '—';
  return new Intl.DateTimeFormat('en-IN', {
    timeZone: INDIA_TIME_ZONE,
    day: '2-digit', month: 'short', year: 'numeric',
  }).format(date);
};

export const fmtTimeIST = value => formatIndiaDate(value, {
  hour: '2-digit', minute: '2-digit', hour12: true,
}, '');
