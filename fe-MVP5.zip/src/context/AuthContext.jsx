import { createContext, useContext, useMemo, useState } from 'react';
import api from '../api/client';

const AuthContext = createContext(null);
export function AuthProvider({ children }) {
  const [user, setUser] = useState(() => JSON.parse(localStorage.getItem('krishi-user') || 'null'));
  const login = async (username, password) => {
    const { data } = await api.post('/login', { username, password });
    localStorage.setItem('krishi-user', JSON.stringify(data)); setUser(data); return data;
  };
  const logout = () => { localStorage.removeItem('krishi-user'); setUser(null); };
  const value = useMemo(() => ({ user, login, logout }), [user]);
  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}
export const useAuth = () => useContext(AuthContext);
