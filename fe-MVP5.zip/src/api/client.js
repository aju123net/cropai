import axios from 'axios';

export const API_URL = import.meta.env.VITE_API_URL || 'http://localhost:8000/api/v1';
export const BACKEND_URL = import.meta.env.VITE_BACKEND_URL || 'http://localhost:8000';

const api = axios.create({ baseURL: API_URL, timeout: 90000 });
api.interceptors.request.use((config) => {
  const user = JSON.parse(localStorage.getItem('krishi-user') || 'null');
  config.headers['X-App-Role'] = user?.role || 'farmer';
  config.headers['X-App-User'] = user?.username || 'farmer';
  return config;
});
api.interceptors.response.use(r => r, error => {
  const detail = error.response?.data?.detail;
  const message = typeof detail === 'string' ? detail : detail?.message || error.message || 'Request failed';
  const appError = new Error(message);
  appError.code = typeof detail === 'object' ? detail?.code : undefined;
  appError.fieldErrors = typeof detail === 'object' ? (detail?.field_errors || {}) : {};
  appError.guardrailMode = typeof detail === 'object' ? detail?.guardrail_mode : undefined;
  appError.status = error.response?.status;
  return Promise.reject(appError);
});
export default api;
