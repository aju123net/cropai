import { Navigate, Route, Routes } from 'react-router-dom';
import { useAuth } from './context/AuthContext';
import Layout from './components/Layout';
import Login from './pages/Login';
import FarmerDashboard from './pages/FarmerDashboard';
import NewAdvisory from './pages/NewAdvisory';
import AdvisoryResult from './pages/AdvisoryResult';
import History from './pages/History';
import Chat from './pages/Chat';
import OfficerQueue from './pages/OfficerQueue';
import AdminDashboard from './pages/AdminDashboard';
import PromptSettings from './pages/PromptSettings';
import KnowledgeBase from './pages/KnowledgeBase';
import SyntheticData from './pages/SyntheticData';
import ModelConfig from './pages/ModelConfig';
import AgentStatus from './pages/AgentStatus';
import Logs from './pages/Logs';

function Protected({roles,children}){const {user}=useAuth();if(!user)return <Navigate to="/login" replace/>;if(roles&&!roles.includes(user.role))return <Navigate to={user.role==='admin'?'/admin':user.role==='officer'?'/officer':'/'} replace/>;return children}
export default function App(){const {user}=useAuth();return <Routes><Route path="/login" element={user?<Navigate to={user.role==='admin'?'/admin':user.role==='officer'?'/officer':'/'}/>:<Login/>}/><Route element={<Protected><Layout/></Protected>}><Route index element={<Protected roles={['farmer']}><FarmerDashboard/></Protected>}/><Route path="new-advisory" element={<Protected roles={['farmer']}><NewAdvisory/></Protected>}/><Route path="advisory/:id" element={<Protected roles={['farmer','officer','admin']}><AdvisoryResult/></Protected>}/><Route path="history" element={<Protected roles={['farmer']}><History/></Protected>}/><Route path="chat" element={<Protected roles={['farmer']}><Chat/></Protected>}/><Route path="officer" element={<Protected roles={['officer']}><OfficerQueue/></Protected>}/><Route path="admin" element={<Protected roles={['admin']}><AdminDashboard/></Protected>}/><Route path="admin/prompts" element={<Protected roles={['admin']}><PromptSettings/></Protected>}/><Route path="admin/knowledge" element={<Protected roles={['admin']}><KnowledgeBase/></Protected>}/><Route path="admin/synthetic" element={<Protected roles={['admin']}><SyntheticData/></Protected>}/><Route path="admin/models" element={<Protected roles={['admin']}><ModelConfig/></Protected>}/><Route path="admin/agents" element={<Protected roles={['admin']}><AgentStatus/></Protected>}/><Route path="admin/logs" element={<Protected roles={['admin']}><Logs/></Protected>}/></Route><Route path="*" element={<Navigate to={user?user.role==='admin'?'/admin':user.role==='officer'?'/officer':'/':'/login'} replace/>}/></Routes>}
