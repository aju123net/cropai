import { useEffect, useState } from 'react';
import { Save } from 'lucide-react';
import api from '../api/client';
import { Alert, Loading, PageHeader } from '../components/Common';

const PROMPT_META = {
  diagnosis_prompt: {
    label: 'Image Analysis Agent',
    help: 'Controls how the vision model extracts visible crop symptoms without making an unsupported diagnosis.',
  },
  recommendation_prompt: {
    label: 'Advisory Agent',
    help: 'Controls the final farmer guidance, including agronomic and economic recommendations.',
  },
  translation_prompt: {
    label: 'Translation Agent',
    help: 'Controls multilingual translation while preserving warnings and agricultural meaning.',
  },
  input_guardrail_prompt: {
    label: 'Input Guardrail Agent',
    help: 'Controls validation of symptoms, fertilizer history, pesticide history, relevance, prompt injection and unsafe input before a case is created.',
  },
  guardrail_prompt: {
    label: 'Output Guardrail Policy',
    help: 'Controls safety constraints applied to generated recommendations, including dosage and low-confidence escalation.',
  },
  conversation_prompt: {
    label: 'Conversational Agent',
    help: 'Controls case-aware follow-up answers using saved conversation history.',
  },
};

export default function PromptSettings(){
  const [data,setData]=useState(null);
  const [msg,setMsg]=useState('');
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);

  useEffect(()=>{
    let active=true;
    api.get('/admin/prompts')
      .then(r=>active&&setData(r.data))
      .catch(e=>active&&setError(e.message));
    return()=>{active=false};
  },[]);

  if(!data)return <Loading/>;

  const save=async()=>{
    setBusy(true);setError('');
    try{
      const response=await api.put('/admin/prompts',data);
      setData(response.data);
      setMsg('Prompt configuration saved successfully.');
    }catch(e){setError(e.message)}finally{setBusy(false)}
  };

  const orderedKeys=Object.keys(PROMPT_META).filter(key=>Object.hasOwn(data,key));
  return <>
    <PageHeader title="Prompt Configuration" description="Configure the six model and safety stages used by the advisory workflow.">
      <button className="btn primary" disabled={busy} onClick={save}><Save size={16}/>{busy?'Saving...':'Save prompts'}</button>
    </PageHeader>
    {msg&&<Alert type="success" onClose={()=>setMsg('')}>{msg}</Alert>}
    {error&&<Alert type="error" onClose={()=>setError('')}>{error}</Alert>}
    <div className="prompt-grid">{orderedKeys.map(key=>{
      const meta=PROMPT_META[key];
      return <div className="card" key={key}>
        <label>{meta.label}</label>
        <textarea rows="10" value={data[key]} onChange={e=>setData({...data,[key]:e.target.value})}/>
        <small>{meta.help}</small>
      </div>
    })}</div>
  </>;
}
