from typing import Any, Optional
from pydantic import BaseModel, Field

class LoginRequest(BaseModel):
    username: str
    password: str

class AdvisoryCreate(BaseModel):
    farmer_name: str = "Farmer"
    crop: str = ""
    variety: str = ""
    growth_stage: str = ""
    location: str = "Kolkata, West Bengal"
    region: str = "West Bengal"
    language: str = "English"
    soil_type: str = ""
    previous_fertilizer: str = ""
    previous_pesticide: str = ""
    symptoms: str = Field(default="", max_length=4000)
    has_image: bool = False

class ChatRequest(BaseModel):
    case_id: int
    message: str = Field(min_length=2, max_length=2000)
    language: str = "English"
    conversation_id: Optional[int] = None

class FeedbackRequest(BaseModel):
    rating: int = Field(ge=1, le=5)
    comment: str = Field(default="", max_length=1000)

class OfficerUpdate(BaseModel):
    note: str = Field(min_length=3, max_length=3000)
    resolved: bool = False

class PromptUpdate(BaseModel):
    diagnosis_prompt: str
    recommendation_prompt: str
    translation_prompt: str
    input_guardrail_prompt: str
    guardrail_prompt: str
    conversation_prompt: str

class ModelUpdate(BaseModel):
    text_model: str
    vision_model: str
    embedding_model: str
    whisper_model: str
    fallback_model: str = ""
    temperature: float = Field(default=0.2, ge=0, le=1.5)
    max_tokens: int = Field(default=1000, ge=128, le=8192)
    context_size: int = Field(default=8000, ge=1000, le=200000)
    active: bool = True
    rag_mode: str = "metadata"

class KnowledgeTextCreate(BaseModel):
    title: str
    content: str = Field(min_length=20)
    crop: str = "All"
    disease: str = "All"
    language: str = "English"
    region: str = "All"

class SyntheticRequest(BaseModel):
    template: str = "Rice disease cases"
    count: int = Field(default=10, ge=1, le=100)

class ToolCallRequest(BaseModel):
    arguments: dict[str, Any] = {}
