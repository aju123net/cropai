from datetime import datetime
from sqlalchemy import Boolean, Column, DateTime, Float, ForeignKey, Integer, String, Text
from sqlalchemy.orm import relationship
from .database import Base

class AdvisoryCase(Base):
    __tablename__ = "advisory_cases"
    id = Column(Integer, primary_key=True)
    owner_username = Column(String(50), index=True, default="farmer")
    farmer_name = Column(String(100), default="Farmer")
    crop = Column(String(80), index=True, nullable=True, default="")
    variety = Column(String(80), default="")
    growth_stage = Column(String(80), default="Vegetative")
    location = Column(String(160), default="")
    region = Column(String(100), default="West Bengal")
    language = Column(String(20), default="English")
    soil_type = Column(String(80), default="")
    previous_fertilizer = Column(Text, default="")
    previous_pesticide = Column(Text, default="")
    symptoms = Column(Text, nullable=True, default="")
    image_path = Column(String(300), default="")
    soil_report_path = Column(String(300), default="")
    soil_report_text = Column(Text, default="")
    image_observations = Column(Text, default="{}")
    weather_context = Column(Text, default="{}")
    soil_context = Column(Text, default="{}")
    disease = Column(String(140), default="Pending")
    confidence = Column(Float, default=0)
    severity = Column(String(30), default="Unknown")
    recommendation = Column(Text, default="")
    prevention = Column(Text, default="")
    retrieved_sources = Column(Text, default="[]")
    agent_trace = Column(Text, default="[]")
    status = Column(String(40), default="Draft", index=True)
    escalated = Column(Boolean, default=False, index=True)
    officer_note = Column(Text, default="")
    feedback_rating = Column(Integer, nullable=True)
    feedback_comment = Column(Text, default="")
    synthetic = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    conversations = relationship("Conversation", back_populates="advisory", cascade="all, delete-orphan")

class Conversation(Base):
    __tablename__ = "conversations"
    id = Column(Integer, primary_key=True)
    case_id = Column(Integer, ForeignKey("advisory_cases.id"), index=True)
    title = Column(String(160), default="Crop advisory follow-up")
    summary = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)
    advisory = relationship("AdvisoryCase", back_populates="conversations")
    messages = relationship("ChatMessage", back_populates="conversation", cascade="all, delete-orphan")

class ChatMessage(Base):
    __tablename__ = "chat_messages"
    id = Column(Integer, primary_key=True)
    conversation_id = Column(Integer, ForeignKey("conversations.id"), index=True)
    role = Column(String(20))
    content = Column(Text)
    language = Column(String(20), default="English")
    created_at = Column(DateTime, default=datetime.utcnow)
    conversation = relationship("Conversation", back_populates="messages")

class KnowledgeDocument(Base):
    __tablename__ = "knowledge_documents"
    id = Column(Integer, primary_key=True)
    title = Column(String(180), nullable=False)
    filename = Column(String(220), default="")
    crop = Column(String(80), default="All", index=True)
    disease = Column(String(120), default="All", index=True)
    language = Column(String(20), default="English")
    region = Column(String(100), default="All")
    content = Column(Text, default="")
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=datetime.utcnow)
    chunks = relationship("KnowledgeChunk", back_populates="document", cascade="all, delete-orphan")

class KnowledgeChunk(Base):
    __tablename__ = "knowledge_chunks"
    id = Column(Integer, primary_key=True)
    document_id = Column(Integer, ForeignKey("knowledge_documents.id"), index=True)
    chunk_index = Column(Integer, default=0)
    content = Column(Text)
    document = relationship("KnowledgeDocument", back_populates="chunks")

class PromptSetting(Base):
    __tablename__ = "prompt_settings"
    id = Column(Integer, primary_key=True)
    key = Column(String(80), unique=True, index=True)
    value = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ModelSetting(Base):
    __tablename__ = "model_settings"
    id = Column(Integer, primary_key=True)
    key = Column(String(80), unique=True, index=True)
    value = Column(Text)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

class ExecutionLog(Base):
    __tablename__ = "execution_logs"
    id = Column(Integer, primary_key=True)
    case_id = Column(Integer, nullable=True, index=True)
    user_role = Column(String(30), default="system")
    agent_name = Column(String(100), default="")
    tool_name = Column(String(100), default="")
    status = Column(String(30), default="SUCCESS", index=True)
    duration_ms = Column(Integer, default=0)
    model_used = Column(String(160), default="")
    input_tokens = Column(Integer, default=0)
    output_tokens = Column(Integer, default=0)
    retrieved_chunks = Column(Integer, default=0)
    message = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)

class GuardrailEvent(Base):
    __tablename__ = "guardrail_events"
    id = Column(Integer, primary_key=True)
    case_id = Column(Integer, nullable=True)
    event_type = Column(String(80))
    action = Column(String(80))
    details = Column(Text, default="")
    created_at = Column(DateTime, default=datetime.utcnow)
