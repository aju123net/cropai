from sqlalchemy.orm import Session
from .catalog import SEED_KNOWLEDGE
from .models import AdvisoryCase, KnowledgeDocument, ModelSetting, PromptSetting
from .services import DEFAULT_MODEL_SETTINGS, DEFAULT_PROMPTS, index_document

def seed_database(db: Session):
    for key, value in DEFAULT_PROMPTS.items():
        if not db.query(PromptSetting).filter_by(key=key).first(): db.add(PromptSetting(key=key,value=value))
    for key, value in DEFAULT_MODEL_SETTINGS.items():
        if not db.query(ModelSetting).filter_by(key=key).first(): db.add(ModelSetting(key=key,value=str(value)))
    db.commit()
    if db.query(KnowledgeDocument).count() == 0:
        for title, crop, disease, content in SEED_KNOWLEDGE:
            doc = KnowledgeDocument(title=title,crop=crop,disease=disease,language="English",region="All",content=content)
            db.add(doc); db.commit(); db.refresh(doc); index_document(db, doc)
    if db.query(AdvisoryCase).count() == 0:
        samples = [
            AdvisoryCase(owner_username="farmer",farmer_name="Ramesh Farmer",crop="Tomato",variety="Pusa Ruby",growth_stage="Fruiting",location="Kolkata, West Bengal",language="English",symptoms="Brown circular spots with concentric rings are visible on older lower leaves.",disease="Early Blight",confidence=86,severity="Moderate",recommendation="Sample completed advisory.",prevention="Improve airflow and field sanitation.",status="Completed"),
            AdvisoryCase(owner_username="farmer",farmer_name="Ramesh Farmer",crop="Rice",growth_stage="Tillering",location="Bardhaman, West Bengal",language="Bengali",symptoms="পাতায় বাদামি ডিম্বাকার দাগ এবং হলুদ বর্ডার দেখা যাচ্ছে।",disease="Brown Spot",confidence=80,severity="Moderate",recommendation="Sample escalated advisory.",prevention="Balanced nutrition and drainage.",status="Escalated",escalated=True),
        ]
        db.add_all(samples); db.commit()
