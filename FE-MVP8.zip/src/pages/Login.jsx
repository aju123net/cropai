import { useState } from 'react';
import { Leaf, LockKeyhole, User } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { Alert } from '../components/Common';

export default function Login(){
  const [form,setForm]=useState({username:'',password:''});
  const [error,setError]=useState('');
  const [busy,setBusy]=useState(false);
  const {login}=useAuth();
  const nav=useNavigate();
  const submit=async e=>{
    e.preventDefault();
    setBusy(true);
    setError('');
    try{
      const u=await login(form.username.trim(),form.password);
      nav(u.role==='admin'?'/admin':u.role==='officer'?'/officer':'/');
    }catch(e){setError(e.message)}finally{setBusy(false)}
  };
  return <div className="login-screen"><div className="login-card">
    <div className="login-brand"><span><Leaf/></span><div><b>KrishiSaarthi AI</b><small>Developed by Brainstormers LAB</small></div></div>
    <h1>Welcome back</h1><p>Sign in to the crop advisory workspace.</p>
    {error&&<Alert type="error">{error}</Alert>}
    <form onSubmit={submit}>
      <label>Username</label><div className="input-icon"><User size={17}/><input autoComplete="username" required value={form.username} onChange={e=>setForm({...form,username:e.target.value})}/></div>
      <label>Password</label><div className="input-icon"><LockKeyhole size={17}/><input autoComplete="current-password" required type="password" value={form.password} onChange={e=>setForm({...form,password:e.target.value})}/></div>
      <button className="btn primary block" disabled={busy}>{busy?'Signing in...':'Sign in'}</button>
    </form>
  </div></div>;
}
