import { useEffect, useRef, useState } from 'react';
import { Clock3, MessageCircle, Mic, Send, Speaker } from 'lucide-react';
import ReactMarkdown from 'react-markdown';
import { useSearchParams } from 'react-router-dom';
import api from '../api/client';
import { Alert, Empty, Loading, PageHeader, fmtDateCompact, fmtTimeIST } from '../components/Common';

export default function Chat() {
  const [params] = useSearchParams();
  const [cases, setCases] = useState(null);
  const [caseId, setCaseId] = useState(params.get('case') || '');
  const [conversations, setConversations] = useState([]);
  const [messages, setMessages] = useState([]);
  const [text, setText] = useState('');
  const [conversationId, setConversationId] = useState(null);
  const [busy, setBusy] = useState(false);
  const [historyBusy, setHistoryBusy] = useState(false);
  const [error, setError] = useState('');
  const endRef = useRef(null);

  useEffect(() => {
    let active = true;

    async function loadCases() {
      try {
        const response = await api.get('/advisories');
        if (!active) return;

        const rows = Array.isArray(response.data) ? response.data : [];
        setCases(rows);
        setCaseId((current) => {
          if (current && rows.some((item) => String(item.id) === String(current))) {
            return String(current);
          }
          return rows[0] ? String(rows[0].id) : '';
        });
      } catch (loadError) {
        if (active) {
          setCases([]);
          setError(loadError.message || 'Unable to load advisory conversations.');
        }
      }
    }

    void loadCases();

    return () => {
      active = false;
    };
  }, []);

  useEffect(() => {
    let active = true;

    async function loadSavedConversation() {
      setMessages([]);
      setConversationId(null);
      setConversations([]);
      setText('');
      setError('');

      if (!caseId) return;

      setHistoryBusy(true);
      try {
        const listResponse = await api.get('/conversations', {
          params: { case_id: Number(caseId) },
        });
        if (!active) return;

        const rows = Array.isArray(listResponse.data) ? listResponse.data : [];
        setConversations(rows);

        // Automatically reopen the latest saved thread for the selected case.
        if (rows.length > 0) {
          const detailResponse = await api.get(`/conversations/${rows[0].id}`);
          if (!active) return;
          setConversationId(rows[0].id);
          setMessages(normaliseMessages(detailResponse.data?.messages));
        }
      } catch (loadError) {
        if (active) {
          setError(loadError.message || 'Unable to load the saved follow-up conversation.');
        }
      } finally {
        if (active) setHistoryBusy(false);
      }
    }

    void loadSavedConversation();

    return () => {
      active = false;
    };
  }, [caseId]);

  useEffect(() => {
    endRef.current?.scrollIntoView({ behavior: 'smooth', block: 'end' });
  }, [messages, busy, historyBusy]);

  if (!cases) return <Loading />;

  const selected = cases.find((item) => String(item.id) === String(caseId));

  const selectCase = (nextCaseId) => {
    setCaseId(String(nextCaseId));
  };

  const selectConversation = async (nextConversationId) => {
    if (busy || String(nextConversationId) === String(conversationId)) return;

    setHistoryBusy(true);
    setError('');
    try {
      const response = await api.get(`/conversations/${nextConversationId}`);
      setConversationId(Number(nextConversationId));
      setMessages(normaliseMessages(response.data?.messages));
      setText('');
    } catch (loadError) {
      setError(loadError.message || 'Unable to load the selected conversation.');
    } finally {
      setHistoryBusy(false);
    }
  };

  const refreshConversationList = async (activeConversationId) => {
    if (!caseId) return;
    try {
      const response = await api.get('/conversations', {
        params: { case_id: Number(caseId) },
      });
      const rows = Array.isArray(response.data) ? response.data : [];
      setConversations(rows);
      if (activeConversationId) setConversationId(Number(activeConversationId));
    } catch {
      // The current chat is already displayed; a list-refresh failure should not
      // hide the successfully generated and persisted LLM response.
    }
  };

  const send = async (value) => {
    const message = String(value || text).trim();
    if (!message || !caseId || busy) return;

    const optimisticUserMessage = {
      role: 'user',
      content: message,
      created_at: new Date().toISOString(),
    };
    setMessages((current) => [...current, optimisticUserMessage]);
    setText('');
    setBusy(true);
    setError('');

    try {
      const response = await api.post('/chat', {
        case_id: Number(caseId),
        message,
        language: selected?.language || 'English',
        conversation_id: conversationId,
      });

      const nextConversationId = response.data.conversation_id;
      setConversationId(nextConversationId);
      setMessages((current) => [
        ...current,
        {
          role: 'assistant',
          content: response.data.answer,
          suggestions: response.data.suggestions,
          model_used: response.data.model_used,
          mode: response.data.mode,
          created_at: new Date().toISOString(),
        },
      ]);
      await refreshConversationList(nextConversationId);
    } catch (sendError) {
      // Remove the optimistic turn because the backend did not confirm that it
      // was saved in the transaction.
      setMessages((current) => current.filter((item) => item !== optimisticUserMessage));
      setError(sendError.message || 'Unable to send the follow-up question.');
    } finally {
      setBusy(false);
    }
  };

  const speak = (content) => {
    if (!('speechSynthesis' in window)) {
      setError('Voice playback is not supported in this browser.');
      return;
    }

    window.speechSynthesis.cancel();
    const utterance = new SpeechSynthesisUtterance(stripMarkdown(content));
    utterance.lang = selected?.language === 'Bengali'
      ? 'bn-IN'
      : selected?.language === 'Hindi'
        ? 'hi-IN'
        : 'en-IN';
    window.speechSynthesis.speak(utterance);
  };

  const voice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Use Chrome or Edge for voice input.');
      return;
    }

    const recognition = new SpeechRecognition();
    recognition.lang = selected?.language === 'Bengali'
      ? 'bn-IN'
      : selected?.language === 'Hindi'
        ? 'hi-IN'
        : 'en-IN';
    recognition.onresult = (event) => setText(event.results[0][0].transcript);
    recognition.onerror = () => setError('Voice input could not be completed. Please try again.');
    recognition.start();
  };

  return (
    <>
      <PageHeader
        title="Conversational Follow-up"
        description="Ask questions using the selected advisory case as conversational RAG context. Saved user and LLM messages reopen automatically."
      />

      {error && <Alert type="error" onClose={() => setError('')}>{error}</Alert>}

      <div className="chat-layout">
        <aside className="card case-list">
          <h3>Select advisory case</h3>
          {cases.length === 0 ? (
            <Empty title="No advisory cases" text="Create a crop advisory before starting a follow-up conversation." />
          ) : cases.map((item) => (
            <button
              type="button"
              className={String(caseId) === String(item.id) ? 'active' : ''}
              onClick={() => selectCase(item.id)}
              key={item.id}
            >
              <b>#{item.id} • {item.crop}</b>
              <span>{item.disease}</span>
            </button>
          ))}

          <div className="conversation-divider" />
          <div className="conversation-title">
            <h3>Saved conversations</h3>
            <span>{conversations.length}</span>
          </div>

          {historyBusy ? (
            <p className="conversation-note">Loading chat history…</p>
          ) : conversations.length === 0 ? (
            <p className="conversation-note">No saved messages for this case yet.</p>
          ) : conversations.map((conversation) => (
            <button
              type="button"
              className={`conversation-item ${String(conversationId) === String(conversation.id) ? 'active' : ''}`}
              onClick={() => void selectConversation(conversation.id)}
              key={conversation.id}
            >
              <b><MessageCircle size={14} /> {conversation.title || `Conversation #${conversation.id}`}</b>
              <span>{conversation.message_count || 0} messages</span>
              <small>{fmtDateCompact(conversation.updated_at)}</small>
            </button>
          ))}
        </aside>

        <section className="card chat-panel">
          <header>
            <div>
              <b>{selected ? `Case #${selected.id}: ${selected.crop}` : 'Choose a case'}</b>
              <small>
                {selected?.disease} {selected && '•'} {selected?.language}
                {conversationId ? ` • Conversation #${conversationId}` : ' • New conversation'}
              </small>
            </div>
          </header>

          <div className="chat-messages">
            {historyBusy ? (
              <Loading text="Loading saved LLM conversation…" />
            ) : messages.length === 0 ? (
              <Empty title="Ask your first follow-up" text="Try: Can it spread? Is there an organic treatment?" />
            ) : messages.map((item, index) => (
              <div key={item.id || `${item.role}-${index}`} className={`bubble-row ${item.role}`}>
                <div className="bubble">
                  {item.role === 'assistant' ? (
                    <div className="chat-markdown">
                      <ReactMarkdown>{normaliseMarkdown(item.content)}</ReactMarkdown>
                    </div>
                  ) : (
                    <p>{item.content}</p>
                  )}

                  <div className="message-meta">
                    {item.created_at && (
                      <span><Clock3 size={11} /> {fmtTimeIST(item.created_at)}</span>
                    )}
                    {item.role === 'assistant' && item.model_used && (
                      <span>{item.mode === 'live' ? 'Live LLM' : 'Fallback'} • {item.model_used}</span>
                    )}
                  </div>

                  {item.role === 'assistant' && (
                    <button type="button" onClick={() => speak(item.content)}>
                      <Speaker size={14} />
                      Listen
                    </button>
                  )}
                  {item.suggestions?.length > 0 && (
                    <div className="suggestions">
                      {item.suggestions.slice(0, 4).map((suggestion) => (
                        <button type="button" key={suggestion} onClick={() => send(suggestion)}>
                          {suggestion}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              </div>
            ))}

            {busy && (
              <div className="bubble-row assistant">
                <div className="bubble typing">Thinking<span /><span /><span /></div>
              </div>
            )}
            <div ref={endRef} />
          </div>

          <footer>
            <button type="button" onClick={voice} aria-label="Use voice input">
              <Mic size={18} />
            </button>
            <textarea
              value={text}
              onChange={(event) => setText(event.target.value)}
              onKeyDown={(event) => {
                if (event.key === 'Enter' && !event.shiftKey) {
                  event.preventDefault();
                  void send();
                }
              }}
              placeholder="Ask about treatment, spread, irrigation or prevention..."
              disabled={!selected || historyBusy}
            />
            <button
              type="button"
              className="btn primary"
              onClick={() => void send()}
              disabled={busy || historyBusy || !caseId || !text.trim()}
            >
              <Send size={17} />
            </button>
          </footer>
        </section>
      </div>
    </>
  );
}

function normaliseMessages(value) {
  if (!Array.isArray(value)) return [];
  return value
    .filter((item) => item && (item.role === 'user' || item.role === 'assistant'))
    .map((item) => ({
      ...item,
      content: String(item.content || ''),
    }));
}

function normaliseMarkdown(value) {
  let text = String(value || '').replace(/\r\n?/g, '\n').trim();
  if (!text) return 'No response was saved.';

  if (/^[{\["]/.test(text)) {
    try {
      const parsed = JSON.parse(text);
      text = String(parsed.answer ?? parsed.content ?? parsed.text ?? parsed.message ?? text);
    } catch {
      // Ordinary Markdown may start with punctuation; keep it unchanged.
    }
  }

  return text
    .replace(/\\r\\n/g, '\n')
    .replace(/\\n/g, '\n')
    .replace(/^\s*```(?:markdown|md|text)?\s*\n?/i, '')
    .replace(/\n?\s*```\s*$/i, '')
    .split('\n')
    .map((line) => line.replace(/^(#{1,6})([^#\s])/, '$1 $2'))
    .join('\n')
    .trim();
}

function stripMarkdown(value) {
  return normaliseMarkdown(value)
    .replace(/```[\s\S]*?```/g, ' ')
    .replace(/!\[[^\]]*\]\([^)]*\)/g, ' ')
    .replace(/\[([^\]]+)\]\([^)]*\)/g, '$1')
    .replace(/^#{1,6}\s+/gm, '')
    .replace(/^\s*[-*+]\s+/gm, '')
    .replace(/^\s*\d+\.\s+/gm, '')
    .replace(/[>*_`~]/g, '')
    .replace(/\n+/g, ' ')
    .replace(/\s+/g, ' ')
    .trim();
}

