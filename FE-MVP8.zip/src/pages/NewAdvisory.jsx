import { useEffect, useRef, useState } from 'react';
import { Camera, FileText, LoaderCircle, Mic, Send, ShieldCheck, Square } from 'lucide-react';
import { useNavigate } from 'react-router-dom';
import api from '../api/client';
import { Alert, Field, PageHeader } from '../components/Common';

const initial = {
  farmer_name: 'Ramesh Farmer',
  crop: 'Tomato',
  variety: '',
  growth_stage: 'Fruiting',
  location: 'Kolkata',
  region: 'West Bengal',
  language: 'English',
  soil_type: 'Alluvial loam',
  previous_fertilizer: '',
  previous_pesticide: '',
  symptoms: '',
};

export default function NewAdvisory() {
  const [form, setForm] = useState(initial);
  const [catalog, setCatalog] = useState(null);
  const [image, setImage] = useState(null);
  const [soil, setSoil] = useState(null);
  const [imageError, setImageError] = useState('');
  const [imageGuardrail, setImageGuardrail] = useState(null);
  const [contextResolution, setContextResolution] = useState(null);
  const [busy, setBusy] = useState(false);
  const [error, setError] = useState('');
  const [fieldErrors, setFieldErrors] = useState({});
  const [listening, setListening] = useState(false);
  const nav = useNavigate();
  const recognition = useRef(null);
  const imageInput = useRef(null);

  useEffect(() => {
    let active = true;
    api.get('/catalog')
      .then((response) => active && setCatalog(response.data))
      .catch((requestError) => active && setError(requestError.message));
    return () => { active = false; };
  }, []);

  const stages = catalog?.crops.find((item) => item.name === form.crop)?.growth_stages || [];

  const clearFieldError = (name) => {
    setFieldErrors((current) => {
      if (!current[name]) return current;
      const next = { ...current };
      delete next[name];
      return next;
    });
  };

  const change = (event) => {
    const { name, value } = event.target;
    setForm((current) => ({ ...current, [name]: value }));
    clearFieldError(name);
    if (error) setError('');
  };

  const voice = () => {
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    if (!SpeechRecognition) {
      setError('Speech recognition is not supported in this browser. Use Chrome or Edge.');
      return;
    }
    if (listening) {
      recognition.current?.stop();
      return;
    }

    const recognizer = new SpeechRecognition();
    recognizer.lang = form.language === 'Bengali' ? 'bn-IN' : form.language === 'Hindi' ? 'hi-IN' : 'en-IN';
    recognizer.interimResults = false;
    recognizer.onresult = (event) => {
      const transcript = event.results[0][0].transcript;
      setForm((current) => ({
        ...current,
        symptoms: `${current.symptoms} ${transcript}`.trim(),
      }));
      clearFieldError('symptoms');
    };
    recognizer.onend = () => setListening(false);
    recognizer.onerror = () => setListening(false);
    recognition.current = recognizer;
    recognizer.start();
    setListening(true);
  };

  const focusFirstInvalidField = (errors) => {
    const firstField = ['crop', 'symptoms', 'previous_fertilizer', 'previous_pesticide']
      .find((name) => errors?.[name]);
    if (!firstField) return;
    window.setTimeout(() => {
      const element = document.querySelector(`[name="${firstField}"]`);
      element?.scrollIntoView({ behavior: 'smooth', block: 'center' });
      element?.focus();
    }, 50);
  };

  const selectImage = (event) => {
    const selected = event.target.files?.[0] || null;
    setImage(selected);
    setImageError('');
    setImageGuardrail(null);
    setContextResolution(null);
    if (error) setError('');
  };

  const submit = async (event) => {
    event.preventDefault();
    setBusy(true);
    setError('');
    setFieldErrors({});
    setImageError('');
    setImageGuardrail(null);
    setContextResolution(null);

    const localErrors = {};
    if (form.symptoms.trim().length < 10) {
      localErrors.symptoms = 'Describe the visible crop problem in at least one meaningful sentence.';
    }
    if (Object.keys(localErrors).length) {
      setFieldErrors(localErrors);
      setError('Please correct the highlighted crop-advisory fields before analysis.');
      setBusy(false);
      focusFirstInvalidField(localErrors);
      return;
    }

    let createdId = null;
    try {
      const { data: created } = await api.post('/advisories', form);
      createdId = created.id;

      if (image) {
        const imageData = new FormData();
        imageData.append('image', image);
        const imageResponse = await api.post(`/advisories/${created.id}/image`, imageData);
        const resolution = imageResponse.data.context_resolution || null;
        setImageGuardrail(imageResponse.data.context_guardrail || null);
        setContextResolution(resolution);

        if (resolution?.auto_corrected && resolution?.resolved_crop) {
          setForm((current) => ({
            ...current,
            crop: resolution.resolved_crop,
            growth_stage: resolution.resolved_growth_stage || current.growth_stage,
          }));
        }
      }

      if (soil) {
        const soilData = new FormData();
        soilData.append('report', soil);
        await api.post(`/advisories/${created.id}/soil-report`, soilData);
      }

      await api.post(`/advisories/${created.id}/analyze`);
      nav(`/advisory/${created.id}`);
    } catch (requestError) {
      const errors = requestError.fieldErrors || {};
      setFieldErrors(errors);

      if (
        requestError.code === 'CROP_IMAGE_REJECTED'
        || requestError.code === 'CROP_IMAGE_VALIDATION_UNAVAILABLE'
        || requestError.code === 'ADVISORY_CONTEXT_MISMATCH'
      ) {
        const imageMessage = requestError.imageError || requestError.message;
        setImageError(imageMessage);
        setImage(null);
        if (imageInput.current) imageInput.current.value = '';
        setImageGuardrail(null);
        setContextResolution(null);
        setError(imageMessage || requestError.message);

        if (createdId) {
          try {
            await api.delete(`/advisories/${createdId}/draft`);
          } catch {
            // Draft cleanup is best-effort and must not hide the guardrail result.
          }
        }
        focusFirstInvalidField(errors);
      } else {
        setError(requestError.message);
        focusFirstInvalidField(errors);
      }
    } finally {
      setBusy(false);
    }
  };

  return <>
    <PageHeader
      title="New Crop Advisory"
      description="Combine crop details, image, text or voice, weather, soil and agricultural knowledge."
    />

    {error && <Alert type="error" onClose={() => setError('')}>{error}</Alert>}

    <form className="card advisory-form" onSubmit={submit} noValidate>
      <div className="input-guardrail-note">
        <ShieldCheck size={19} />
        <div>
          <b>Input and image guardrails enabled</b>
          <span>Only meaningful crop details and images relevant to agricultural crop health are accepted.</span>
        </div>
      </div>

      <div className="step-title">
        <span>1</span>
        <div><h3>Crop and farm details</h3><p>Choose the crop, stage, location and preferred response language.</p></div>
      </div>
      <div className="form-grid">
        <Field label="Farmer name"><input name="farmer_name" value={form.farmer_name} onChange={change} /></Field>
        <Field label="Crop" error={fieldErrors.crop}>
          <select
            name="crop"
            value={form.crop}
            aria-invalid={Boolean(fieldErrors.crop)}
            onChange={(event) => {
              const crop = event.target.value;
              const growthStage = catalog?.crops.find((item) => item.name === crop)?.growth_stages?.[0] || 'Vegetative';
              setForm((current) => ({ ...current, crop, growth_stage: growthStage }));
            }}
          >
            {catalog?.crops.map((item) => <option key={item.name}>{item.name}</option>)}
          </select>
        </Field>
        <Field label="Variety"><input name="variety" value={form.variety} onChange={change} placeholder="Optional" /></Field>
        <Field label="Growth stage"><select name="growth_stage" value={form.growth_stage} onChange={change}>{stages.map((stage) => <option key={stage}>{stage}</option>)}</select></Field>
        <Field label="Location"><input name="location" value={form.location} onChange={change} /></Field>
        <Field label="Region"><select name="region" value={form.region} onChange={change}>{catalog?.regions.map((region) => <option key={region}>{region}</option>)}</select></Field>
        <Field label="Response language"><select name="language" value={form.language} onChange={change}>{catalog?.languages.map((language) => <option key={language}>{language}</option>)}</select></Field>
        <Field label="Soil type"><select name="soil_type" value={form.soil_type} onChange={change}>{catalog?.soil_types.map((type) => <option key={type}>{type}</option>)}</select></Field>
      </div>

      <hr />
      <div className="step-title">
        <span>2</span>
        <div><h3>Image and soil report</h3><p>Use a clear close-up crop image. Soil report is optional.</p></div>
      </div>
      <div className="upload-grid">
        <div>
          <label className={`upload-box ${imageError ? 'invalid' : ''}`}>
            <Camera size={30} />
            <b>{image ? image.name : 'Upload crop image'}</b>
            <small>JPG or PNG. Non-farming images are blocked by the Image Context Guardrail.</small>
            <input ref={imageInput} type="file" accept="image/*" capture="environment" onChange={selectImage} />
          </label>
          {imageError && <small className="field-error image-error">{imageError}</small>}
          {imageGuardrail?.allowed && (
            <small className="image-accepted">
              <ShieldCheck size={14} />
              Crop image validated
              {imageGuardrail.detected_crop ? ` • Detected: ${imageGuardrail.detected_crop}` : ''}
            </small>
          )}
          {contextResolution?.auto_corrected && (
            <small className="image-accepted">
              <ShieldCheck size={14} />
              Crop selection adjusted to {contextResolution.resolved_crop} using image and symptom context.
            </small>
          )}
        </div>
        <label className="upload-box">
          <FileText size={30} /><b>{soil ? soil.name : 'Upload soil report'}</b><small>PDF, JPG or PNG — optional</small>
          <input type="file" accept=".pdf,image/*" onChange={(event) => setSoil(event.target.files[0])} />
        </label>
      </div>

      <hr />
      <div className="step-title">
        <span>3</span>
        <div><h3>Describe the crop problem</h3><p>Type or use the microphone. Personal phone/email details will be masked.</p></div>
      </div>

      <Field label="Symptoms and recent changes" error={fieldErrors.symptoms}>
        <div className="voice-field">
          <textarea
            name="symptoms"
            value={form.symptoms}
            onChange={change}
            rows="6"
            required
            aria-invalid={Boolean(fieldErrors.symptoms)}
            placeholder="Describe visible symptoms, affected plant parts, when the problem started, and any recent weather or irrigation changes."
          />
          <button type="button" className={listening ? 'recording' : ''} onClick={voice}>
            {listening ? <Square size={18} /> : <Mic size={18} />} {listening ? 'Stop' : 'Voice input'}
          </button>
        </div>
      </Field>

      <div className="form-grid">
        <Field label="Previous fertilizer usage" error={fieldErrors.previous_fertilizer}>
          <textarea
            name="previous_fertilizer"
            value={form.previous_fertilizer}
            onChange={change}
            rows="3"
            aria-invalid={Boolean(fieldErrors.previous_fertilizer)}
            placeholder="Example: Urea 10 kg/acre applied 7 days ago. Leave blank or write Not used."
          />
        </Field>
        <Field label="Previous pesticide usage" error={fieldErrors.previous_pesticide}>
          <textarea
            name="previous_pesticide"
            value={form.previous_pesticide}
            onChange={change}
            rows="3"
            aria-invalid={Boolean(fieldErrors.previous_pesticide)}
            placeholder="Example: Neem oil sprayed 5 days ago. Leave blank or write Not used."
          />
        </Field>
      </div>

      <div className="submit-row">
        <p>AI-generated guidance indicates a possible condition and does not replace field inspection or local agricultural advice.</p>
        <button className="btn primary" disabled={busy}>
          {busy
            ? <><LoaderCircle className="spin" size={18} />Validating and running multi-agent analysis...</>
            : <><Send size={18} />Analyze crop problem</>}
        </button>
      </div>
    </form>
  </>;
}
