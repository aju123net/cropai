import { useEffect, useState } from 'react';
import { ArrowRight, CheckCircle2, Clock3, Leaf, MessageCircle, Plus, ShieldAlert } from 'lucide-react';
import { Link } from 'react-router-dom';
import api from '../api/client';
import { Empty, Loading, PageHeader, StatusBadge, fmtDate, fmtDateOnly } from '../components/Common';

export default function FarmerDashboard(){
 const [cases,setCases]=useState(null); useEffect(()=>{api.get('/advisories').then(r=>setCases(r.data)).catch(()=>setCases([]))},[]);
 if(!cases)return <Loading/>; const completed=cases.filter(x=>x.status==='Completed'||x.status==='Resolved').length; const escalated=cases.filter(x=>x.escalated).length;
 return <><section className="hero"><div><span className="eyebrow"><Leaf size={14}/> SMART FARMING ASSISTANT</span><h1>Protect your crop with faster, explainable AI guidance.</h1><p>Upload a crop image, describe the symptoms, and receive a grounded advisory using vision analysis, disease rules, agricultural knowledge, weather, and soil context.</p><Link className="btn white" to="/new-advisory"><Plus size={17}/> Start new advisory</Link></div><SproutArt/></section>
 <div className="kpi-grid"><Kpi icon={Leaf} label="Total cases" value={cases.length}/><Kpi icon={CheckCircle2} label="Completed" value={completed}/><Kpi icon={ShieldAlert} label="Escalated" value={escalated}/><Kpi icon={Clock3} label="Latest update" value={cases[0]?fmtDateOnly(cases[0].created_at):'—'}/></div>
 <div className="section-title"><h2>Recent advisory cases</h2><Link to="/history">View all <ArrowRight size={14}/></Link></div><div className="card table-card">{cases.length===0?<Empty title="No advisory cases" text="Create your first crop advisory to begin."/>:<table><thead><tr><th>Case</th><th>Crop & symptoms</th><th>Possible condition</th><th>Status</th><th>Created</th><th/></tr></thead><tbody>{cases.slice(0,6).map(c=><tr key={c.id}><td><b>#{c.id}</b></td><td><b>{c.crop}</b><small>{c.symptoms.slice(0,58)}...</small></td><td>{c.disease}<small>{c.confidence?`${c.confidence}% confidence`:''}</small></td><td><StatusBadge value={c.status}/></td><td>{fmtDate(c.created_at)}</td><td><Link className="icon-link" to={`/advisory/${c.id}`}><ArrowRight size={16}/></Link></td></tr>)}</tbody></table>}</div></>;
}
function Kpi({icon:Icon,label,value}){return <div className="card kpi"><span><Icon/></span><div><small>{label}</small><b>{value}</b></div></div>}
function SproutArt(){return <svg className="hero-art" viewBox="0 0 200 200" fill="none"><circle cx="100" cy="100" r="75" stroke="currentColor" strokeWidth="2"/><path d="M100 150V92M100 112c-31 0-52-21-52-52 31 0 52 21 52 52Zm0-20c25 0 43-17 43-43-25 0-43 17-43 43Z" stroke="currentColor" strokeWidth="7" strokeLinecap="round" strokeLinejoin="round"/></svg>}
