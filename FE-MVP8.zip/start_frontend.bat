@echo off
if not exist .env copy .env.example .env
call npm install
npm run dev
